import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (keeping the original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone"),
  role: text("role").default("customer").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const loginSchema = z.object({
  username: z.string().min(3, "Nome de usuário deve ter pelo menos 3 caracteres"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
});

export const registerSchema = z.object({
  username: z.string().min(3, "Nome de usuário deve ter pelo menos 3 caracteres"),
  email: z.string().email("E-mail inválido"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  phone: z.string().min(10, "Telefone deve ter pelo menos 10 caracteres").optional(),
});

// Internet Plans
export const plans = pgTable("plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  speed: integer("speed").notNull(),
  price: integer("price").notNull(), // in cents
  description: text("description").notNull(),
  features: text("features").array().notNull(),
  isPopular: boolean("is_popular").default(false),
  installationTime: text("installation_time").notNull(),
  supportLevel: text("support_level").notNull(),
});

export const insertPlanSchema = createInsertSchema(plans).omit({
  id: true,
});

export type InsertPlan = z.infer<typeof insertPlanSchema>;
export type Plan = typeof plans.$inferSelect;

// Customer Information
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  documentNumber: text("document_number").notNull(), // CPF or CNPJ
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  zipCode: text("zip_code").notNull(),
  street: text("street").notNull(),
  number: text("number").notNull(),
  complement: text("complement"),
  neighborhood: text("neighborhood").notNull(),
  city: text("city").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
});

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

// Orders
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  planId: integer("plan_id").notNull(),
  amount: integer("amount").notNull(), // total amount in cents
  status: text("status").notNull().default("pending"), 
  paymentMethod: text("payment_method").notNull(),
  installments: integer("installments").notNull(),
  paymentId: text("payment_id"), // Mercado Pago payment ID
  mercadoPagoResponse: json("mercado_pago_response"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Form schemas with validations
export const customerFormSchema = z.object({
  name: z.string().min(3, "Nome completo é obrigatório"),
  documentNumber: z.string().min(11, "CPF/CNPJ é obrigatório"),
  email: z.string().email("Email inválido"),
  phone: z.string().min(10, "Telefone inválido"),
  zipCode: z.string().min(8, "CEP inválido"),
  street: z.string().min(3, "Rua é obrigatória"),
  number: z.string().min(1, "Número é obrigatório"),
  complement: z.string().optional(),
  neighborhood: z.string().min(2, "Bairro é obrigatório"),
  city: z.string().min(2, "Cidade é obrigatória"),
});

export const paymentFormSchema = z.object({
  planId: z.number(),
  paymentMethod: z.enum(["credit_card", "boleto", "pix"]),
  installments: z.number().min(1),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "Você precisa aceitar os termos de serviço"
  }),
});

// Checkout state type
export type CheckoutState = {
  step: number;
  selectedPlan: Plan | null;
  customer: InsertCustomer | null;
  payment: {
    paymentMethod: "credit_card" | "boleto" | "pix";
    installments: number;
    termsAccepted: boolean;
  } | null;
};

// Tabela de conexão entre usuários e clientes
export const userCustomers = pgTable("user_customers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  customerId: integer("customer_id").notNull(),
});

// Tabela de assinaturas de serviço
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  planId: integer("plan_id").notNull(),
  status: text("status").notNull().default("active"), // active, suspended, cancelled
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  cancelDate: timestamp("cancel_date"),
  renewalDate: timestamp("renewal_date").notNull(),
  autoRenew: boolean("auto_renew").default(true).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

// Tabela de pagamentos (histórico de pagamentos)
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  subscriptionId: integer("subscription_id").notNull(),
  customerId: integer("customer_id").notNull(),
  amount: integer("amount").notNull(), // in cents
  paymentMethod: text("payment_method").notNull(),
  status: text("status").notNull().default("pending"), // pending, paid, failed, refunded
  externalId: text("external_id"), // ID do pagamento no gateway genérico
  mercadoPagoId: text("mercado_pago_id"), // ID específico do Mercado Pago
  paymentDate: timestamp("payment_date"),
  dueDate: timestamp("due_date").notNull(),
  notes: text("notes"),
  receiptUrl: text("receipt_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

// Order confirmation response
export type OrderConfirmation = {
  order: Order;
  customer: Customer;
  plan: Plan;
  paymentDetails: {
    method: string;
    status: string;
    date: string;
    receiptUrl?: string;
  };
};
