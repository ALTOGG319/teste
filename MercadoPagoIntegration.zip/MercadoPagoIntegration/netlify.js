// Este script é usado para preparar os arquivos para o Netlify
import { execSync } from 'child_process';
import { mkdirSync, copyFileSync, existsSync } from 'fs';
import { join } from 'path';

// Executa o build do frontend
console.log('Building frontend...');
execSync('npm run build', { stdio: 'inherit' });

// Cria diretório para as funções serverless
console.log('Creating Netlify functions directory...');
const functionsDir = join(process.cwd(), 'netlify', 'functions');
if (!existsSync(functionsDir)) {
  mkdirSync(functionsDir, { recursive: true });
}

// Prepara os arquivos _redirects para o build
console.log('Copying _redirects file to dist...');
copyFileSync(join(process.cwd(), '_redirects'), join(process.cwd(), 'dist', '_redirects'));

console.log('Build completed successfully!');