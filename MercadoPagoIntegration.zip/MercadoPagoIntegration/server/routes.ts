import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { customerFormSchema, insertOrderSchema, paymentFormSchema } from "@shared/schema";
import { MercadoPagoConfig, Payment } from "mercadopago";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure authentication
  setupAuth(app);
  
  // Initialize Mercado Pago
  const mercadopago = new MercadoPagoConfig({ 
    accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN || 'TEST-8582059915303170-121311-02bab2b95bef8eec7e5e1e6b0e4d5e80-163725322' 
  });
  const payment = new Payment(mercadopago);
  
  // Get all plans
  app.get("/api/plans", async (req, res) => {
    try {
      const plans = await storage.getPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching plans:", error);
      res.status(500).json({ message: "Failed to fetch plans" });
    }
  });
  
  // Get a single plan by ID
  app.get("/api/plans/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid plan ID" });
      }
      
      const plan = await storage.getPlan(id);
      if (!plan) {
        return res.status(404).json({ message: "Plan not found" });
      }
      
      res.json(plan);
    } catch (error) {
      console.error("Error fetching plan:", error);
      res.status(500).json({ message: "Failed to fetch plan" });
    }
  });
  
  // Create order and process payment
  app.post("/api/checkout", async (req, res) => {
    try {
      // Validate customer data
      const customerValidation = customerFormSchema.safeParse(req.body.customer);
      if (!customerValidation.success) {
        return res.status(400).json({ 
          message: "Invalid customer data", 
          errors: customerValidation.error.errors 
        });
      }
      
      // Validate payment data
      const paymentValidation = paymentFormSchema.safeParse(req.body.payment);
      if (!paymentValidation.success) {
        return res.status(400).json({ 
          message: "Invalid payment data", 
          errors: paymentValidation.error.errors 
        });
      }
      
      const customerData = customerValidation.data;
      const paymentData = paymentValidation.data;
      
      // Get plan
      const plan = await storage.getPlan(paymentData.planId);
      if (!plan) {
        return res.status(404).json({ message: "Plan not found" });
      }
      
      // Create customer
      const customer = await storage.createCustomer(customerData);
      
      // Create order
      const orderData = {
        customerId: customer.id,
        planId: plan.id,
        amount: plan.price,
        status: "pending",
        paymentMethod: paymentData.paymentMethod,
        installments: paymentData.installments,
      };
      
      const order = await storage.createOrder(orderData);
      
      // API para perfil do cliente
  app.get("/api/customers", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const userId = (req.user as any).id;
      const customers = await storage.getCustomersByUserId(userId);
      res.json(customers);
    } catch (error) {
      console.error("Error fetching customer data:", error);
      res.status(500).json({ message: "Falha ao buscar dados do cliente" });
    }
  });
  
  app.get("/api/subscriptions", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const userId = (req.user as any).id;
      const customers = await storage.getCustomersByUserId(userId);
      
      if (!customers.length) {
        return res.json([]);
      }
      
      // Buscar assinaturas de todos os clientes associados ao usuário
      const subscriptions = [];
      for (const customer of customers) {
        const customerSubscriptions = await storage.getSubscriptionsByCustomerId(customer.id);
        subscriptions.push(...customerSubscriptions);
      }
      
      res.json(subscriptions);
    } catch (error) {
      console.error("Error fetching subscriptions:", error);
      res.status(500).json({ message: "Falha ao buscar assinaturas" });
    }
  });
  
  app.get("/api/payments", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const userId = (req.user as any).id;
      const customers = await storage.getCustomersByUserId(userId);
      
      if (!customers.length) {
        return res.json([]);
      }
      
      // Buscar pagamentos de todos os clientes associados ao usuário
      const payments = [];
      for (const customer of customers) {
        const customerPayments = await storage.getPaymentsByCustomerId(customer.id);
        payments.push(...customerPayments);
      }
      
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Falha ao buscar pagamentos" });
    }
  });
  
  // APIs para administração (protegidas)
  app.get("/api/admin/users", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const user = req.user as any;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Acesso não autorizado" });
      }
      
      // Implementação fictícia - retornar usuários dummy para demonstração
      // Em produção, buscaria usuários do banco de dados
      const mockUsers = [
        {
          id: 1,
          name: "Admin Principal",
          username: "admin",
          email: "admin@altonet.com.br",
          role: "admin",
          phone: "(74) 99999-9999",
          createdAt: new Date("2023-01-01")
        },
        {
          id: 2,
          name: user.name,
          username: user.username,
          email: user.email,
          role: user.role,
          phone: user.phone || null,
          createdAt: user.createdAt
        }
      ];
      
      res.json(mockUsers);
    } catch (error) {
      console.error("Error fetching admin users:", error);
      res.status(500).json({ message: "Falha ao buscar usuários" });
    }
  });
  
  app.get("/api/admin/customers", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const user = req.user as any;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Acesso não autorizado" });
      }
      
      // Em produção, buscaria todos os clientes do banco de dados
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      console.error("Error fetching admin customers:", error);
      res.status(500).json({ message: "Falha ao buscar clientes" });
    }
  });
  
  app.get("/api/admin/subscriptions", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const user = req.user as any;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Acesso não autorizado" });
      }
      
      // Em produção, buscaria todas as assinaturas do banco de dados
      const subscriptions = await storage.getSubscriptions();
      res.json(subscriptions);
    } catch (error) {
      console.error("Error fetching admin subscriptions:", error);
      res.status(500).json({ message: "Falha ao buscar assinaturas" });
    }
  });
  
  app.get("/api/admin/payments", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const user = req.user as any;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Acesso não autorizado" });
      }
      
      // Em produção, buscaria todos os pagamentos do banco de dados
      const payments = await storage.getPayments();
      res.json(payments);
    } catch (error) {
      console.error("Error fetching admin payments:", error);
      res.status(500).json({ message: "Falha ao buscar pagamentos" });
    }
  });
  
  app.get("/api/admin/dashboard", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Não autenticado" });
      }
      
      const user = req.user as any;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Acesso não autorizado" });
      }
      
      // Em produção, buscaria métricas reais do dashboard
      const dashboardData = {
        totalRevenue: await storage.getTotalRevenue(),
        activeSubscriptions: await storage.getActiveSubscriptionsCount(),
        totalCustomers: (await storage.getCustomers()).length,
        recentPayments: await storage.getRecentPayments(5),
        revenueByMonth: await storage.getRevenueByPeriod('monthly'),
        planDistribution: [
          { label: 'Fibra 100', value: 12 },
          { label: 'Fibra 200', value: 24 },
          { label: 'Fibra 400', value: 16 },
          { label: 'Rádio 10', value: 8 },
          { label: 'Rádio 30', value: 8 }
        ]
      };
      
      res.json(dashboardData);
    } catch (error) {
      console.error("Error fetching admin dashboard:", error);
      res.status(500).json({ message: "Falha ao buscar dados do dashboard" });
    }
  });
  
  // Process payment with Mercado Pago
      if (paymentData.paymentMethod === "credit_card") {
        // For credit card, we need token from frontend
        if (!req.body.token) {
          return res.status(400).json({ message: "Payment token is required" });
        }
        
        try {
          const paymentResult = await payment.create({
            body: {
              token: req.body.token,
              installments: paymentData.installments,
              transaction_amount: plan.price / 100, // Convert cents to real currency unit
              description: `JONATASNET - ${plan.name}`,
              payment_method_id: "visa", // This would come from the frontend in a real scenario
              payer: {
                email: customerData.email,
                identification: {
                  type: customerData.documentNumber.length <= 11 ? "CPF" : "CNPJ",
                  number: customerData.documentNumber
                }
              }
            }
          });
          
          // Update order with payment result
          await storage.updateOrder(order.id, {
            status: paymentResult.status === "approved" ? "completed" : paymentResult.status,
            paymentId: paymentResult.id?.toString(),
            mercadoPagoResponse: paymentResult
          });
          
          // Get updated order
          const updatedOrder = await storage.getOrder(order.id);
          
          // Return success response
          res.json({
            order: updatedOrder,
            customer,
            plan,
            paymentDetails: {
              method: paymentData.paymentMethod,
              status: updatedOrder?.status || "processing",
              date: new Date().toISOString(),
              receiptUrl: paymentResult.id ? `https://www.mercadopago.com.br/activities/${paymentResult.id}` : undefined
            }
          });
        } catch (mpError: any) {
          console.error("Mercado Pago error:", mpError);
          // Update order status to failed
          await storage.updateOrder(order.id, {
            status: "failed",
            mercadoPagoResponse: mpError.response?.data || mpError
          });
          
          res.status(400).json({
            message: "Payment processing failed",
            error: mpError.response?.data?.message || "An error occurred with the payment processor"
          });
        }
      } else if (paymentData.paymentMethod === "boleto" || paymentData.paymentMethod === "pix") {
        // For boleto and PIX, we'll just simulate success in this demo
        // In a real app, we would generate the boleto/PIX with Mercado Pago
        
        // Simulate delay for processing
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Update order status
        await storage.updateOrder(order.id, {
          status: "pending_payment",
          paymentId: `SIMULATED-${Date.now()}`,
          mercadoPagoResponse: {
            status: "pending",
            status_detail: "pending_payment",
            id: `SIMULATED-${Date.now()}`
          }
        });
        
        // Get updated order
        const updatedOrder = await storage.getOrder(order.id);
        
        // Return success response
        res.json({
          order: updatedOrder,
          customer,
          plan,
          paymentDetails: {
            method: paymentData.paymentMethod,
            status: "pending_payment",
            date: new Date().toISOString(),
            // In a real app, this would be the URL to the boleto or PIX code from Mercado Pago
            receiptUrl: paymentData.paymentMethod === "boleto" 
              ? "https://www.mercadopago.com.br/boleto" 
              : "https://www.mercadopago.com.br/pix"
          }
        });
      } else {
        res.status(400).json({ message: "Unsupported payment method" });
      }
    } catch (error) {
      console.error("Error processing checkout:", error);
      res.status(500).json({ message: "Failed to process checkout" });
    }
  });
  
  // Get order status
  app.get("/api/orders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      const customer = await storage.getCustomer(order.customerId);
      const plan = await storage.getPlan(order.planId);
      
      if (!customer || !plan) {
        return res.status(404).json({ message: "Order data incomplete" });
      }
      
      res.json({
        order,
        customer,
        plan,
        paymentDetails: {
          method: order.paymentMethod,
          status: order.status,
          date: (order.createdAt || new Date()).toISOString(),
          receiptUrl: order.paymentId ? `https://www.mercadopago.com.br/activities/${order.paymentId}` : undefined
        }
      });
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
