import { 
  users, type User, type InsertUser,
  plans, type Plan, type InsertPlan,
  customers, type Customer, type InsertCustomer,
  orders, type Order, type InsertOrder,
  userCustomers, subscriptions, type Subscription, type InsertSubscription,
  payments, type Payment, type InsertPayment
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

// Storage interface with CRUD methods
export interface IStorage {
  // Session store
  sessionStore: any;
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUser(username: string, password: string): Promise<User | null>;
  getUsers(): Promise<User[]>;
  
  // Plans
  getPlans(): Promise<Plan[]>;
  getPlan(id: number): Promise<Plan | undefined>;
  createPlan(plan: InsertPlan): Promise<Plan>;
  updatePlan(id: number, updates: Partial<Plan>): Promise<Plan | undefined>;
  deletePlan(id: number): Promise<boolean>;
  
  // Customers
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  getCustomersByUserId(userId: number): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, updates: Partial<Customer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;
  linkUserToCustomer(userId: number, customerId: number): Promise<boolean>;
  getCustomers(): Promise<Customer[]>;
  
  // Orders
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByCustomerId(customerId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined>;
  
  // Subscriptions
  getSubscription(id: number): Promise<Subscription | undefined>;
  getSubscriptionsByCustomerId(customerId: number): Promise<Subscription[]>;
  getActiveSubscriptionsByCustomerId(customerId: number): Promise<Subscription[]>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined>;
  cancelSubscription(id: number): Promise<Subscription | undefined>;
  getSubscriptions(): Promise<Subscription[]>;
  
  // Payments
  getPayment(id: number): Promise<Payment | undefined>;
  getPaymentsBySubscriptionId(subscriptionId: number): Promise<Payment[]>;
  getPaymentsByCustomerId(customerId: number): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: number, updates: Partial<Payment>): Promise<Payment | undefined>;
  getPayments(): Promise<Payment[]>;
  
  // Dashboard Data
  getRecentPayments(limit?: number): Promise<Payment[]>;
  getActiveSubscriptionsCount(): Promise<number>;
  getTotalRevenue(startDate?: Date, endDate?: Date): Promise<number>;
  getRevenueByPeriod(period: 'daily' | 'monthly' | 'yearly'): Promise<{label: string, value: number}[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private plans: Map<number, Plan>;
  private customers: Map<number, Customer>;
  private orders: Map<number, Order>;
  private userCustomerLinks: Map<number, {userId: number, customerId: number}>;
  private subscriptions: Map<number, Subscription>;
  private payments: Map<number, Payment>;
  
  private userCurrentId: number;
  private planCurrentId: number;
  private customerCurrentId: number;
  private orderCurrentId: number;
  private userCustomerLinkCurrentId: number;
  private subscriptionCurrentId: number;
  private paymentCurrentId: number;

  // Session store
  sessionStore: any;

  constructor() {
    this.users = new Map();
    this.plans = new Map();
    this.customers = new Map();
    this.orders = new Map();
    this.userCustomerLinks = new Map();
    this.subscriptions = new Map();
    this.payments = new Map();
    
    this.userCurrentId = 1;
    this.planCurrentId = 1;
    this.customerCurrentId = 1;
    this.orderCurrentId = 1;
    this.userCustomerLinkCurrentId = 1;
    this.subscriptionCurrentId = 1;
    this.paymentCurrentId = 1;
    
    // Inicializar o session store
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // limpar sessões expiradas a cada 24h
    });
    
    // Initialize with default plans
    this.seedPlans();
  }
  
  // Seed the database with initial plans
  private seedPlans() {
    const defaultPlans: InsertPlan[] = [
      // Planos de Fibra Óptica
      {
        name: "Fibra 100",
        speed: 100,
        price: 7000, // R$ 70,00
        description: "Internet de fibra óptica de alta velocidade",
        features: [
          "100 Mbps de velocidade",
          "Navegação ilimitada",
          "Instalação em até 5 dias úteis",
          "Suporte técnico em horário comercial"
        ],
        isPopular: false,
        installationTime: "até 5 dias úteis",
        supportLevel: "horário comercial"
      },
      {
        name: "Fibra 200",
        speed: 200,
        price: 10000, // R$ 100,00
        description: "Internet de fibra óptica para uso intenso",
        features: [
          "200 Mbps de velocidade",
          "Navegação ilimitada",
          "Instalação em até 3 dias úteis",
          "Suporte técnico 24/7",
          "IP fixo"
        ],
        isPopular: true,
        installationTime: "até 3 dias úteis",
        supportLevel: "24/7"
      },
      {
        name: "Fibra 400",
        speed: 400,
        price: 14000, // R$ 140,00
        description: "A melhor experiência em internet de fibra óptica",
        features: [
          "400 Mbps de velocidade",
          "Navegação ilimitada",
          "Instalação em até 24h",
          "Suporte técnico 24/7 prioritário",
          "IP fixo + Redundância"
        ],
        isPopular: false,
        installationTime: "até 24h",
        supportLevel: "24/7 prioritário"
      },
      
      // Planos de Internet via Rádio
      {
        name: "Rádio 10",
        speed: 10,
        price: 5000, // R$ 50,00
        description: "Internet via rádio para locais sem fibra óptica",
        features: [
          "10 Mbps de velocidade",
          "Navegação ilimitada",
          "Instalação em até 2 dias úteis",
          "Ideal para áreas rurais e remotas"
        ],
        isPopular: false,
        installationTime: "até 2 dias úteis",
        supportLevel: "horário comercial"
      },
      {
        name: "Rádio 30",
        speed: 30,
        price: 6000, // R$ 60,00
        description: "Internet via rádio com maior velocidade",
        features: [
          "30 Mbps de velocidade",
          "Navegação ilimitada",
          "Instalação em até 2 dias úteis",
          "Suporte técnico em horário comercial",
          "Ideal para áreas rurais e remotas com mais dispositivos"
        ],
        isPopular: false,
        installationTime: "até 2 dias úteis",
        supportLevel: "horário comercial"
      }
    ];
    
    defaultPlans.forEach(plan => {
      this.createPlan(plan);
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const createdAt = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt,
      role: insertUser.role || "customer",
      phone: insertUser.phone || null
    };
    this.users.set(id, user);
    return user;
  }
  
  async validateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    // Em produção, você usaria bcrypt ou similar para comparar senhas
    if (user.password === password) {
      return user;
    }
    
    return null;
  }
  
  // Plans
  async getPlans(): Promise<Plan[]> {
    return Array.from(this.plans.values());
  }
  
  async getPlan(id: number): Promise<Plan | undefined> {
    return this.plans.get(id);
  }
  
  async createPlan(insertPlan: InsertPlan): Promise<Plan> {
    const id = this.planCurrentId++;
    // Garante que isPopular tenha um valor booleano padrão (false) se não for fornecido
    const plan: Plan = { 
      ...insertPlan, 
      id,
      isPopular: insertPlan.isPopular === undefined ? false : insertPlan.isPopular 
    };
    this.plans.set(id, plan);
    return plan;
  }
  
  async updatePlan(id: number, updates: Partial<Plan>): Promise<Plan | undefined> {
    const existingPlan = await this.getPlan(id);
    if (!existingPlan) return undefined;
    
    const updatedPlan = { ...existingPlan, ...updates };
    this.plans.set(id, updatedPlan);
    return updatedPlan;
  }
  
  async deletePlan(id: number): Promise<boolean> {
    const exists = this.plans.has(id);
    if (!exists) return false;
    
    return this.plans.delete(id);
  }
  
  // Customers
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }
  
  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    return Array.from(this.customers.values()).find(
      (customer) => customer.email === email,
    );
  }
  
  async getCustomersByUserId(userId: number): Promise<Customer[]> {
    const userCustomerLinksForUser = Array.from(this.userCustomerLinks.values())
      .filter(link => link.userId === userId);
    
    return userCustomerLinksForUser.map(link => 
      this.customers.get(link.customerId)
    ).filter((customer): customer is Customer => customer !== undefined);
  }
  
  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.customerCurrentId++;
    const createdAt = new Date();
    // Garante que complement tenha um valor nulo se não for fornecido
    const customer: Customer = { 
      ...insertCustomer, 
      id, 
      createdAt,
      complement: insertCustomer.complement || null 
    };
    this.customers.set(id, customer);
    return customer;
  }
  
  async updateCustomer(id: number, updates: Partial<Customer>): Promise<Customer | undefined> {
    const existingCustomer = await this.getCustomer(id);
    if (!existingCustomer) return undefined;
    
    const updatedCustomer = { ...existingCustomer, ...updates };
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }
  
  async deleteCustomer(id: number): Promise<boolean> {
    const exists = this.customers.has(id);
    if (!exists) return false;
    
    // Remover também as referências em userCustomerLinks
    Array.from(this.userCustomerLinks.entries())
      .filter(([_, link]) => link.customerId === id)
      .forEach(([linkId, _]) => this.userCustomerLinks.delete(linkId));
    
    return this.customers.delete(id);
  }
  
  async linkUserToCustomer(userId: number, customerId: number): Promise<boolean> {
    // Verifica se o usuário e o cliente existem
    const user = await this.getUser(userId);
    const customer = await this.getCustomer(customerId);
    
    if (!user || !customer) return false;
    
    // Verifica se já existe uma ligação
    const existingLink = Array.from(this.userCustomerLinks.values())
      .find(link => link.userId === userId && link.customerId === customerId);
    
    if (existingLink) return true; // Já existe a ligação
    
    // Cria nova ligação
    const id = this.userCustomerLinkCurrentId++;
    this.userCustomerLinks.set(id, { userId, customerId });
    
    return true;
  }
  
  // Orders
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async getOrdersByCustomerId(customerId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.customerId === customerId
    );
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderCurrentId++;
    const createdAt = new Date();
    // Garante que todos os campos obrigatórios tenham valores
    const order: Order = { 
      ...insertOrder, 
      id, 
      createdAt,
      status: insertOrder.status || "pending",
      paymentId: insertOrder.paymentId || null,
      mercadoPagoResponse: insertOrder.mercadoPagoResponse || null
    };
    this.orders.set(id, order);
    return order;
  }
  
  async updateOrder(id: number, updates: Partial<Order>): Promise<Order | undefined> {
    const existingOrder = await this.getOrder(id);
    if (!existingOrder) return undefined;
    
    const updatedOrder = { ...existingOrder, ...updates };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
  
  // Subscriptions
  async getSubscription(id: number): Promise<Subscription | undefined> {
    return this.subscriptions.get(id);
  }
  
  async getSubscriptionsByCustomerId(customerId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values()).filter(
      (subscription) => subscription.customerId === customerId
    );
  }
  
  async getActiveSubscriptionsByCustomerId(customerId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values()).filter(
      (subscription) => 
        subscription.customerId === customerId && 
        subscription.status === 'active'
    );
  }
  
  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const id = this.subscriptionCurrentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    
    const subscription: Subscription = { 
      id, 
      createdAt,
      updatedAt,
      customerId: insertSubscription.customerId,
      planId: insertSubscription.planId,
      status: insertSubscription.status || "active",
      startDate: insertSubscription.startDate || new Date(),
      endDate: insertSubscription.endDate || null,
      cancelDate: insertSubscription.cancelDate || null,
      renewalDate: insertSubscription.renewalDate,
      autoRenew: insertSubscription.autoRenew !== undefined ? insertSubscription.autoRenew : true,
      notes: insertSubscription.notes || null
    };
    
    this.subscriptions.set(id, subscription);
    return subscription;
  }
  
  async updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    const existingSubscription = await this.getSubscription(id);
    if (!existingSubscription) return undefined;
    
    // Atualiza o updatedAt sempre que modificar uma assinatura
    const updatedSubscription = { 
      ...existingSubscription, 
      ...updates,
      updatedAt: new Date()
    };
    
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }
  
  async cancelSubscription(id: number): Promise<Subscription | undefined> {
    const existingSubscription = await this.getSubscription(id);
    if (!existingSubscription) return undefined;
    
    const cancelDate = new Date();
    
    const updatedSubscription = { 
      ...existingSubscription, 
      status: 'cancelled',
      cancelDate,
      updatedAt: new Date()
    };
    
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }
  
  // Payments
  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }
  
  async getPaymentsBySubscriptionId(subscriptionId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(
      (payment) => payment.subscriptionId === subscriptionId
    );
  }
  
  async getPaymentsByCustomerId(customerId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(
      (payment) => payment.customerId === customerId
    );
  }
  
  // Implementação de getUsers
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Implementação de getCustomers
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }
  
  // Implementação de getSubscriptions
  async getSubscriptions(): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values());
  }
  
  // Implementação de getPayments
  async getPayments(): Promise<Payment[]> {
    return Array.from(this.payments.values());
  }
  
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.paymentCurrentId++;
    const createdAt = new Date();
    
    const payment: Payment = { 
      id, 
      createdAt,
      customerId: insertPayment.customerId,
      subscriptionId: insertPayment.subscriptionId,
      amount: insertPayment.amount,
      paymentMethod: insertPayment.paymentMethod,
      status: insertPayment.status || "pending",
      externalId: insertPayment.externalId || null,
      mercadoPagoId: insertPayment.mercadoPagoId || null,
      paymentDate: insertPayment.paymentDate || null,
      dueDate: insertPayment.dueDate,
      notes: insertPayment.notes || null,
      receiptUrl: insertPayment.receiptUrl || null
    };
    
    this.payments.set(id, payment);
    return payment;
  }
  
  async updatePayment(id: number, updates: Partial<Payment>): Promise<Payment | undefined> {
    const existingPayment = await this.getPayment(id);
    if (!existingPayment) return undefined;
    
    const updatedPayment = { ...existingPayment, ...updates };
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }
  
  // Dashboard Data
  async getRecentPayments(limit: number = 10): Promise<Payment[]> {
    return Array.from(this.payments.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
  
  async getActiveSubscriptionsCount(): Promise<number> {
    return Array.from(this.subscriptions.values())
      .filter(sub => sub.status === 'active')
      .length;
  }
  
  async getTotalRevenue(startDate?: Date, endDate?: Date): Promise<number> {
    let payments = Array.from(this.payments.values());
    
    if (startDate) {
      payments = payments.filter(payment => payment.createdAt >= startDate);
    }
    
    if (endDate) {
      payments = payments.filter(payment => payment.createdAt <= endDate);
    }
    
    return payments.reduce((total, payment) => total + payment.amount, 0);
  }
  
  async getRevenueByPeriod(period: 'daily' | 'monthly' | 'yearly'): Promise<{label: string, value: number}[]> {
    const payments = Array.from(this.payments.values());
    const revenueByPeriod = new Map<string, number>();
    
    payments.forEach(payment => {
      let label: string;
      const date = payment.createdAt;
      
      if (period === 'daily') {
        // Formato: DD/MM/AAAA
        label = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
      } else if (period === 'monthly') {
        // Formato: MM/AAAA
        label = `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
      } else { // yearly
        // Formato: AAAA
        label = date.getFullYear().toString();
      }
      
      revenueByPeriod.set(label, (revenueByPeriod.get(label) || 0) + payment.amount);
    });
    
    // Converter o Map para um array de objetos {label, value}
    return Array.from(revenueByPeriod.entries()).map(([label, value]) => ({
      label,
      value
    }));
  }
}

export const storage = new MemStorage();
