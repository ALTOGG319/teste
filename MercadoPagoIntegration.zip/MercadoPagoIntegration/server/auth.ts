import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";

// Define um tipo para o User do Passport
type UserType = {
  id: number;
  username: string;
  password: string;
  email: string;
  name: string;
  phone: string | null;
  role: string;
  createdAt: Date;
}

declare global {
  namespace Express {
    interface User extends UserType {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "jonatasnet-secret-key",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias
      secure: process.env.NODE_ENV === "production", 
      sameSite: 'lax'
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return done(null, false, { message: "Usuário não encontrado" });
      }

      try {
        // Em produção, usaria comparePasswords para comparar senhas com hash
        // Para facilitar o desenvolvimento, estamos usando comparação direta
        if (user.password !== password) {
          return done(null, false, { message: "Senha incorreta" });
        }

        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user: Express.User, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { username, email, password, name } = req.body;

      // Verifica se o usuário ou email já existem
      const existingUser = await storage.getUserByUsername(username);
      const existingEmail = await storage.getUserByEmail(email);

      if (existingUser) {
        return res.status(400).json({ message: "Nome de usuário já existe" });
      }

      if (existingEmail) {
        return res.status(400).json({ message: "E-mail já cadastrado" });
      }

      // Em produção, usaria hashPassword para criar hash da senha
      // Para facilitar o desenvolvimento, estamos armazenando a senha diretamente
      // Verifica se é o primeiro usuário para torná-lo admin
      const allUsers = await storage.getUsers();
      const isFirstUser = allUsers.length === 0;
      
      // Garantir que o papel seja sempre "customer" a menos que seja o primeiro usuário
      const userRole = isFirstUser ? "admin" : "customer";
      
      const user = await storage.createUser({
        username: username || 'admin',
        email: email || 'admin@altonet.com.br',
        password: password, // Sempre usar a senha fornecida
        name: name || username || 'Administrador',
        role: userRole
      });

      req.login(user, (err) => {
        if (err) return next(err);
        // Retorna o usuário sem a senha
        const { password, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: User | false, info: { message: string } | undefined) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Falha na autenticação" });
      }
      req.login(user, (err) => {
        if (err) return next(err);
        // Retorna o usuário sem a senha
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.status(200).json({ message: "Logout realizado com sucesso" });
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Não autenticado" });
    }

    // Retorna o usuário sem a senha
    const { password, ...userWithoutPassword } = req.user as Express.User;
    res.json(userWithoutPassword);
  });
}