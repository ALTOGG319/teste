// Este arquivo é o entry-point para funções Netlify
// Ele exporta as funções do handler necessárias

// Função principal para a API
export { handler as api } from './netlify-functions.ts';