import { createContext, useContext, useReducer, ReactNode } from "react";
import { CheckoutState, Plan, InsertCustomer, OrderConfirmation } from "@shared/schema";

// Define action types
type CheckoutAction =
  | { type: 'NEXT_STEP' }
  | { type: 'PREV_STEP' }
  | { type: 'SET_STEP', payload: number }
  | { type: 'SET_PLAN', payload: Plan }
  | { type: 'SET_CUSTOMER', payload: InsertCustomer }
  | { type: 'SET_PAYMENT', payload: { paymentMethod: 'credit_card' | 'boleto' | 'pix', installments: number, termsAccepted: boolean } }
  | { type: 'SET_CONFIRMATION', payload: OrderConfirmation }
  | { type: 'RESET' };

// Initial state
const initialState: CheckoutState & { confirmation: OrderConfirmation | null } = {
  step: 1,
  selectedPlan: null,
  customer: null,
  payment: null,
  confirmation: null
};

// Checkout context
const CheckoutContext = createContext<{
  state: typeof initialState;
  dispatch: React.Dispatch<CheckoutAction>;
}>({
  state: initialState,
  dispatch: () => null
});

// Reducer function
const checkoutReducer = (state: typeof initialState, action: CheckoutAction): typeof initialState => {
  switch (action.type) {
    case 'NEXT_STEP':
      return {
        ...state,
        step: Math.min(state.step + 1, 4)
      };
    case 'PREV_STEP':
      return {
        ...state,
        step: Math.max(state.step - 1, 1)
      };
    case 'SET_STEP':
      return {
        ...state,
        step: action.payload
      };
    case 'SET_PLAN':
      return {
        ...state,
        selectedPlan: action.payload
      };
    case 'SET_CUSTOMER':
      return {
        ...state,
        customer: action.payload
      };
    case 'SET_PAYMENT':
      return {
        ...state,
        payment: action.payload
      };
    case 'SET_CONFIRMATION':
      return {
        ...state,
        confirmation: action.payload
      };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
};

// Provider component
export const CheckoutProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(checkoutReducer, initialState);
  
  return (
    <CheckoutContext.Provider value={{ state, dispatch }}>
      {children}
    </CheckoutContext.Provider>
  );
};

// Hook to use the checkout context
export const useCheckout = () => {
  const context = useContext(CheckoutContext);
  if (!context) {
    throw new Error('useCheckout must be used within a CheckoutProvider');
  }
  return context;
};
