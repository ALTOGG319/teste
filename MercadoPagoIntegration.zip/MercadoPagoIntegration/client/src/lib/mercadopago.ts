// Mercado Pago integration library
import { useEffect, useState } from "react";

declare global {
  interface Window {
    MercadoPago: any;
  }
}

export type MercadoPagoInstance = any; // O SDK v2 do MercadoPago tem uma API mais complexa

// Default public key - should be replaced with environment variable
const MERCADO_PAGO_PUBLIC_KEY = import.meta.env.VITE_MERCADO_PAGO_PUBLIC_KEY || 'TEST-c5a00d53-b43e-4b9a-b03d-62f67eb20e28';

export const loadMercadoPagoScript = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (window.MercadoPago) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://sdk.mercadopago.com/js/v2';
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Mercado Pago SDK'));
    
    document.body.appendChild(script);
  });
};

export const useMercadoPago = () => {
  const [mercadopago, setMercadopago] = useState<MercadoPagoInstance | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let isMounted = true;

    const initialize = async () => {
      try {
        setLoading(true);
        await loadMercadoPagoScript();
        
        if (window.MercadoPago && isMounted) {
          const mp = new window.MercadoPago(MERCADO_PAGO_PUBLIC_KEY);
          setMercadopago(mp);
          setError(null);
        }
      } catch (err) {
        if (isMounted) {
          console.error('Error initializing Mercado Pago:', err);
          setError(err instanceof Error ? err : new Error('Failed to initialize Mercado Pago'));
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initialize();

    return () => {
      isMounted = false;
    };
  }, []);

  return { mercadopago, loading, error };
};

export const createCardForm = (
  mercadopago: MercadoPagoInstance,
  container: string,
  callbacks: {
    onFormMounted?: () => void;
    onSubmit?: (event: any) => void;
    onError?: (error: any) => void;
    onBinChange?: (bin: string) => void;
  }
) => {
  if (!mercadopago) return null;
  
  try {
    // Simulação do formulário do cartão para demonstração
    // O MercadoPago v2 usa uma API diferente da implementada originalmente
    const cardContainer = document.getElementById(container);
    
    if (cardContainer) {
      // Criar campos de formulário simulados
      cardContainer.innerHTML = `
        <div class="mp-form-demo">
          <div class="mp-form-row">
            <label class="mp-form-label">Nome no cartão</label>
            <input type="text" class="mp-form-input" placeholder="Nome como aparece no cartão" />
          </div>
          <div class="mp-form-row">
            <label class="mp-form-label">Número do cartão</label>
            <input type="text" class="mp-form-input" placeholder="0000 0000 0000 0000" />
          </div>
          <div class="mp-form-group">
            <div class="mp-form-row mp-form-half">
              <label class="mp-form-label">Validade</label>
              <input type="text" class="mp-form-input" placeholder="MM/YY" />
            </div>
            <div class="mp-form-row mp-form-half">
              <label class="mp-form-label">CVV</label>
              <input type="text" class="mp-form-input" placeholder="123" />
            </div>
          </div>
          <style>
            .mp-form-demo { padding: 15px; border-radius: 6px; background: #f8f9fa; }
            .mp-form-row { margin-bottom: 15px; }
            .mp-form-label { display: block; margin-bottom: 6px; font-size: 14px; font-weight: 500; color: #333; }
            .mp-form-input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
            .mp-form-group { display: flex; gap: 10px; }
            .mp-form-half { flex: 1; }
          </style>
        </div>
      `;
      
      // Notificar que o formulário foi montado
      callbacks.onFormMounted?.();
      
      // Implementar mock de submissão
      const submitEventHandler = (e: Event) => {
        e.preventDefault();
        if (callbacks.onSubmit) {
          callbacks.onSubmit({ preventDefault: () => {} });
        }
      };
      
      // Adicionar estilo ao container para simular o formulário do MercadoPago
      cardContainer.style.backgroundColor = '#f8f9fa';
      cardContainer.style.borderRadius = '6px';
      cardContainer.style.padding = '10px';
      
      return {
        // Mock para retornar um objeto similar ao que o MercadoPago retorna
        submit: () => {
          callbacks.onSubmit?.({ preventDefault: () => {} });
        },
        unmount: () => {
          if (cardContainer) {
            cardContainer.innerHTML = '';
          }
        }
      };
    }
    
    return null;
  } catch (error) {
    console.error('Error creating card form:', error);
    callbacks.onError?.(error);
    return null;
  }
};
