import { useCheckout } from "@/hooks/use-checkout";

interface CheckoutProgressProps {
  currentStep: number;
}

export default function CheckoutProgress({ currentStep }: CheckoutProgressProps) {
  const stepTitles = [
    "Escolha do Plano",
    "Dados Pessoais",
    "Pagamento",
    "Confirmação"
  ];
  
  // Calculate progress percentage
  const progressPercentage = ((currentStep - 1) / 3) * 100;
  
  return (
    <div className="flex justify-center mb-8">
      <div className="w-full max-w-4xl">
        <div className="flex flex-wrap justify-between items-center relative">
          {/* Progress Bar */}
          <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-200 -z-10"></div>
          <div 
            className="absolute top-1/2 left-0 h-1 bg-primary transition-all duration-500 -z-10" 
            style={{ width: `${progressPercentage}%` }}
          ></div>
          
          {/* Steps */}
          {stepTitles.map((title, index) => {
            const stepNumber = index + 1;
            const isActive = stepNumber <= currentStep;
            
            return (
              <div key={stepNumber} className="flex flex-col items-center relative z-10">
                <div className={`w-10 h-10 flex items-center justify-center rounded-full mb-2 font-bold
                  ${isActive ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'}`}>
                  {stepNumber}
                </div>
                <span className={`text-sm md:text-base font-medium 
                  ${isActive ? '' : 'text-gray-600'}`}>
                  {title}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
