import { useCheckout } from "@/hooks/use-checkout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckIcon, DownloadIcon, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Step4Confirmation() {
  const { state } = useCheckout();
  const { confirmation } = state;
  
  if (!confirmation) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8 text-center">
        <p>Não foi possível obter os dados da confirmação.</p>
      </div>
    );
  }
  
  const { order, customer, plan, paymentDetails } = confirmation;
  
  // Format date to a readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    }).format(date);
  };
  
  // Determine status display
  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'completed':
        return { text: 'Confirmado', color: 'text-green-600' };
      case 'pending_payment':
        return { text: 'Aguardando pagamento', color: 'text-yellow-600' };
      case 'failed':
        return { text: 'Falha no processamento', color: 'text-red-600' };
      default:
        return { text: 'Em processamento', color: 'text-blue-600' };
    }
  };
  
  const statusDisplay = getStatusDisplay(order.status);
  
  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8 text-center">
      <div className="mb-6">
        <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckIcon className="h-10 w-10 text-white" />
        </div>
        
        <h2 className="text-2xl font-bold text-green-600 mb-2">
          {order.status === 'completed' 
            ? 'Pagamento Confirmado!' 
            : order.status === 'pending_payment'
              ? 'Pedido Registrado!'
              : 'Pedido Processado!'}
        </h2>
        
        <p className="text-gray-600">
          {order.status === 'completed' 
            ? 'Seu pagamento foi processado com sucesso.' 
            : order.status === 'pending_payment'
              ? 'Aguardando a confirmação do seu pagamento.'
              : 'Seu pedido foi registrado no sistema.'}
        </p>
      </div>
      
      <div className="bg-gray-50 p-6 rounded-md mb-6 text-left">
        <h3 className="font-semibold text-lg mb-4 text-primary">Detalhes da compra</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-gray-500">Plano</p>
            <p className="font-medium">{plan.name} ({plan.speed} Mbps)</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Total</p>
            <p className="font-medium">R$ {(order.amount / 100).toFixed(2)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Forma de pagamento</p>
            <p className="font-medium">
              {order.paymentMethod === 'credit_card' 
                ? 'Cartão de crédito' 
                : order.paymentMethod === 'boleto'
                  ? 'Boleto bancário'
                  : 'PIX'}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Status</p>
            <p className={`font-medium ${statusDisplay.color}`}>
              {statusDisplay.text}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Data</p>
            <p className="font-medium">{formatDate(paymentDetails.date)}</p>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-4 mt-4">
          <h4 className="font-medium mb-2">Agendamento da instalação</h4>
          <p className="text-gray-600 mb-3">Nossa equipe entrará em contato em até 24 horas para agendar a instalação.</p>
          <p className="text-sm text-gray-500">Um comprovante foi enviado para seu e-mail.</p>
        </div>
      </div>
      
      <div className="flex flex-wrap justify-center gap-4">
        {paymentDetails.receiptUrl && (
          <a 
            href={paymentDetails.receiptUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-6 py-2 border border-primary text-primary rounded-full font-medium transition-all duration-300 hover:bg-primary hover:text-white flex items-center"
          >
            <DownloadIcon className="mr-2 h-4 w-4" />
            Visualizar recibo
          </a>
        )}
        
        <Link href="/">
          <Button className="px-6 py-2 bg-primary text-white rounded-full font-medium transition-all duration-300 hover:bg-opacity-90 flex items-center">
            Ir para página inicial
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  );
}
