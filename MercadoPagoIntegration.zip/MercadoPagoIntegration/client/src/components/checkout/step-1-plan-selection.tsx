import { useQuery } from "@tanstack/react-query";
import { Plan } from "@shared/schema";
import { CheckIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useCheckout } from "@/hooks/use-checkout";
import { Badge } from "@/components/ui/badge";

export default function Step1PlanSelection() {
  const { state, dispatch } = useCheckout();
  const { data: plans, isLoading } = useQuery<Plan[]>({
    queryKey: ['/api/plans'],
  });
  
  const handleSelectPlan = (plan: Plan) => {
    dispatch({ type: 'SET_PLAN', payload: plan });
    // Avança para o próximo passo automaticamente (etapa 2)
    dispatch({ type: 'SET_STEP', payload: 2 });
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center my-12">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  return (
    <div className="transition-all duration-500 transform">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-primary mb-4">Escolha seu Plano</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Selecione o plano que melhor atende às necessidades da sua empresa
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {plans?.map((plan) => (
          <Card 
            key={plan.id} 
            className={`overflow-hidden transition-all duration-300 cursor-pointer group 
              ${state.selectedPlan?.id === plan.id 
                ? 'border-2 border-secondary shadow-lg' 
                : 'border-2 border-transparent hover:border-secondary'}
              ${plan.isPopular ? 'md:scale-105' : ''}
            `}
            onClick={() => handleSelectPlan(plan)}
          >
            <CardHeader className={`p-4 ${plan.isPopular 
              ? 'bg-gradient-to-r from-secondary to-orange-600' 
              : 'bg-gradient-to-r from-primary to-blue-900'} text-white text-center relative`}
            >
              {plan.isPopular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-500 text-white text-xs px-4 py-1 rounded-full font-bold">
                  MAIS POPULAR
                </div>
              )}
              <h3 className="text-xl font-bold">{plan.name}</h3>
            </CardHeader>
            
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <span className="text-4xl font-bold text-primary">
                  R$ {(plan.price / 100).toFixed(0)}
                </span>
                <span className="text-gray-600">/mês</span>
              </div>
              
              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckIcon className="h-5 w-5 text-green-500 shrink-0 mt-0.5 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                className={`w-full text-white font-medium ${plan.isPopular 
                  ? 'bg-orange-500 hover:bg-orange-600' 
                  : 'bg-blue-600 hover:bg-blue-700'}`}
                onClick={() => handleSelectPlan(plan)}
              >
                Selecionar
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Botão de continuar removido - agora a seleção avança automaticamente */}
    </div>
  );
}
