import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { customerFormSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useCheckout } from "@/hooks/use-checkout";
import { useToast } from "@/hooks/use-toast";
import GooglePlacesAddressForm from "./google-places-address-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

type FormValues = {
  name: string;
  documentNumber: string;
  email: string;
  phone: string;
  zipCode: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
};

export default function Step2PersonalInfo() {
  const { state, dispatch } = useCheckout();
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(customerFormSchema),
    defaultValues: state.customer ? {
      ...state.customer,
      complement: state.customer.complement || ""
    } : {
      name: "",
      documentNumber: "",
      email: "",
      phone: "",
      zipCode: "",
      street: "",
      number: "",
      complement: "",
      neighborhood: "",
      city: "",
    },
  });
  
  const handleSubmit = (data: FormValues) => {
    dispatch({ type: 'SET_CUSTOMER', payload: data });
    dispatch({ type: 'NEXT_STEP' });
  };
  
  const handleBack = () => {
    dispatch({ type: 'PREV_STEP' });
  };
  
  return (
    <div className="transition-all duration-500 transform">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-primary mb-4">Dados Pessoais</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Preencha seus dados para prosseguir com o pagamento
        </p>
        
        {state.selectedPlan && (
          <div className="mt-4 inline-block px-6 py-3 bg-green-100 border border-green-300 rounded-lg shadow-sm">
            <p className="text-green-800 font-medium">
              Plano selecionado: <span className="font-bold">{state.selectedPlan.name}</span> - 
              R$ {(state.selectedPlan.price / 100).toFixed(2)}/mês
            </p>
          </div>
        )}
      </div>
      
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome Completo</FormLabel>
                      <FormControl>
                        <Input placeholder="Seu nome completo" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="documentNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CPF/CNPJ</FormLabel>
                      <FormControl>
                        <Input placeholder="000.000.000-00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>E-mail</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="seu@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefone</FormLabel>
                      <FormControl>
                        <Input placeholder="(00) 00000-0000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-3 text-primary">
                  Endereço para Instalação
                </h3>
                
                {/* Usando o componente de autopreenchimento do Google Places */}
                <div className="mt-4">
                  <GooglePlacesAddressForm form={form} />
                </div>
              </div>
              
              <div className="flex justify-between mt-8">
                <Button
                  type="button"
                  variant="outline"
                  className="px-6 py-2 border border-primary text-primary rounded-full font-medium transition-all duration-300 hover:bg-primary hover:text-white"
                  onClick={handleBack}
                >
                  Voltar
                </Button>
                
                <Button
                  type="submit"
                  className="px-8 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-full font-semibold shadow-md transition-all duration-300 hover:shadow-lg"
                >
                  Continuar
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
