import { Dialog, DialogContent } from "@/components/ui/dialog";

interface PaymentProcessingModalProps {
  isOpen: boolean;
}

export default function PaymentProcessingModal({ isOpen }: PaymentProcessingModalProps) {
  return (
    <Dialog open={isOpen} modal={true}>
      <DialogContent className="p-8 max-w-md w-full text-center">
        <div className="mb-6">
          <div className="w-16 h-16 border-4 border-t-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
        <h3 className="text-xl font-bold mb-2">Processando seu pagamento</h3>
        <p className="text-gray-600 mb-4">
          Por favor, aguarde enquanto processamos seu pagamento através do Mercado Pago. Não feche esta janela.
        </p>
        
        <div className="flex justify-center">
          <img 
            src="https://seeklogo.com/images/M/mercado-pago-logo-52B7182205-seeklogo.com.png" 
            alt="Mercado Pago" 
            className="h-8" 
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
