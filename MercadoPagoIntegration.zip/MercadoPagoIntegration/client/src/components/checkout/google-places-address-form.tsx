import { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { UseFormReturn } from "react-hook-form";
import { Loader2, MapPin, AlertTriangle } from "lucide-react";
import GooglePlacesInput from './google-places-input';

// Verifica se a API do Google Maps já falhou antes para evitar tentativas repetidas
let googleMapsLoadFailed = false;

type FormValues = {
  name: string;
  documentNumber: string;
  email: string;
  phone: string;
  zipCode: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
};

interface GooglePlacesAddressFormProps {
  form: UseFormReturn<FormValues>;
}

export default function GooglePlacesAddressForm({ form }: GooglePlacesAddressFormProps) {
  const [showManualAddressForm, setShowManualAddressForm] = useState(googleMapsLoadFailed);
  const [hasGoogleMapsError, setHasGoogleMapsError] = useState(googleMapsLoadFailed);
  
  // Quando o componente recebe um erro do Google Maps, mostra o formulário manual
  const handleGoogleMapsError = () => {
    googleMapsLoadFailed = true;
    setHasGoogleMapsError(true);
    setShowManualAddressForm(true);
  };

  const handlePlaceSelect = (place: {
    fullAddress: string;
    street: string;
    number: string;
    neighborhood: string;
    city: string;
    zipCode: string;
  }) => {
    try {
      form.setValue('street', place.street, { shouldValidate: true });
      form.setValue('number', place.number, { shouldValidate: true });
      form.setValue('neighborhood', place.neighborhood, { shouldValidate: true });
      form.setValue('city', place.city, { shouldValidate: true });
      form.setValue('zipCode', place.zipCode, { shouldValidate: true });
      
      // Se não tiver um número, deixamos o campo editável
      if (!place.number) {
        const streetInput = document.querySelector('input[name="number"]') as HTMLInputElement;
        if (streetInput) {
          streetInput.readOnly = false;
          streetInput.classList.remove('bg-gray-50');
          streetInput.focus();
        }
      }
    } catch (error) {
      console.error('Erro ao preencher o formulário com o endereço:', error);
    }
  };

  return (
    <div className="space-y-6">
      {hasGoogleMapsError && (
        <div className="bg-red-50 border border-red-200 rounded-md p-3 mb-4">
          <p className="text-sm text-red-700 flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Não foi possível carregar o serviço de busca automática de endereços. Por favor, preencha seu endereço manualmente.
          </p>
        </div>
      )}
      
      {!showManualAddressForm ? (
        <>
          <div className="bg-green-50 border border-green-200 rounded-md p-3 mb-4">
            <p className="text-sm text-green-700 flex items-center">
              <MapPin className="h-4 w-4 mr-2" />
              Digite seu endereço abaixo e selecione uma das opções para preenchimento automático
            </p>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-md p-3 mb-4">
            <p className="text-xs text-blue-700">
              <strong>Dica:</strong> Digite seu endereço completo (por exemplo: "Rua das Flores, 123, Centro, Capim Grosso"). À medida que você digita, o Google sugerirá endereços para facilitar o preenchimento!
            </p>
          </div>
          
          <div className="mb-4">
            <GooglePlacesInput 
              onPlaceSelect={handlePlaceSelect}
              onError={handleGoogleMapsError}
              placeholder="Digite seu endereço completo (Ex: Rua das Flores, 123, Bairro, Cidade)"
              className="mb-2"
            />
            
            <div className="text-center mt-4">
              <Button 
                type="button" 
                variant="link" 
                onClick={() => setShowManualAddressForm(true)}
                className="text-sm"
              >
                Prefiro preencher manualmente
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="street"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rua</FormLabel>
                  <FormControl>
                    <Input {...field} readOnly className="bg-gray-50" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Número</FormLabel>
                  <FormControl>
                    <Input {...field} className={field.value ? "bg-gray-50" : ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="complement"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Complemento (opcional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Apto, Bloco, etc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="neighborhood"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bairro</FormLabel>
                  <FormControl>
                    <Input {...field} readOnly className="bg-gray-50" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cidade</FormLabel>
                  <FormControl>
                    <Input {...field} readOnly className="bg-gray-50" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="zipCode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>CEP</FormLabel>
                  <FormControl>
                    <Input {...field} readOnly className="bg-gray-50" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </>
      ) : (
        <>
          <div className="bg-blue-50 border border-blue-200 rounded-md p-3 mb-4">
            <p className="text-sm text-blue-700">
              Preencha manualmente os campos de endereço abaixo
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="zipCode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>CEP</FormLabel>
                  <FormControl>
                    <Input placeholder="00000-000" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="street"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rua</FormLabel>
                  <FormControl>
                    <Input placeholder="Nome da rua" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Número</FormLabel>
                  <FormControl>
                    <Input placeholder="123" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="complement"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Complemento (opcional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Apto, Bloco, etc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="neighborhood"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bairro</FormLabel>
                  <FormControl>
                    <Input placeholder="Seu bairro" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cidade</FormLabel>
                  <FormControl>
                    <Input placeholder="Sua cidade" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          {!hasGoogleMapsError && (
            <div className="text-center">
              <Button 
                type="button" 
                variant="link" 
                onClick={() => setShowManualAddressForm(false)}
                className="text-sm"
              >
                Usar preenchimento automático
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}