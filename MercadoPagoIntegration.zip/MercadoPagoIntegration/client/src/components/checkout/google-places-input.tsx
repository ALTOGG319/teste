import { useEffect, useRef, useState } from 'react';
import { useLoadScript } from '@react-google-maps/api';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, MapPin } from "lucide-react";

// Define as bibliotecas a serem carregadas como uma constante fora do componente
import type { Libraries } from '@react-google-maps/api/dist/utils/make-load-script-url';
const libraries: Libraries = ['places'];

interface GooglePlacesInputProps {
  onPlaceSelect: (place: {
    fullAddress: string;
    street: string;
    number: string;
    neighborhood: string;
    city: string;
    zipCode: string;
  }) => void;
  onError?: () => void;
  placeholder?: string;
  className?: string;
}

export default function GooglePlacesInput({ onPlaceSelect, onError, placeholder = "Digite seu endereço", className }: GooglePlacesInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const autoCompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [inputValue, setInputValue] = useState<string>("");
  const [isTyping, setIsTyping] = useState(false);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
    libraries,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    setIsTyping(true);

    // Limpar timeout anterior
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Definir novo timeout
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
    }, 500);
  };

  useEffect(() => {
    if (!isLoaded || !inputRef.current || isTyping) return;

    try {
      const options = {
        componentRestrictions: { country: 'br' },
        fields: ['address_components', 'formatted_address', 'geometry', 'name'],
      };

      // Limpar qualquer instância anterior
      if (autoCompleteRef.current) {
        google.maps.event.clearInstanceListeners(autoCompleteRef.current);
        autoCompleteRef.current = null;
      }

      // Criar nova instância
      autoCompleteRef.current = new window.google.maps.places.Autocomplete(
        inputRef.current,
        options
      );

      // Adicionar listener para o evento 'place_changed'
      const listener = autoCompleteRef.current.addListener('place_changed', () => {
        if (!autoCompleteRef.current) return;
        
        setIsLoading(true);

        try {
          const place = autoCompleteRef.current.getPlace();
          if (!place.address_components) {
            setIsLoading(false);
            return;
          }
          
          // Atualiza o valor do input com o endereço formatado
          if (place.formatted_address) {
            setInputValue(place.formatted_address);
          }

          const addressObj = {
            fullAddress: place.formatted_address || '',
            street: '',
            number: '',
            neighborhood: '',
            city: '',
            zipCode: '',
          };

          for (const component of place.address_components) {
            const componentType = component.types[0];

            switch (componentType) {
              case 'street_number':
                addressObj.number = component.long_name;
                break;
              case 'route':
                addressObj.street = component.long_name;
                break;
              case 'sublocality_level_1':
              case 'sublocality':
              case 'neighborhood':
                addressObj.neighborhood = component.long_name;
                break;
              case 'administrative_area_level_2':
                addressObj.city = component.long_name;
                break;
              case 'postal_code':
                addressObj.zipCode = component.long_name.replace('-', '');
                break;
            }
          }

          onPlaceSelect(addressObj);
        } catch (error) {
          console.error('Erro ao processar o lugar selecionado:', error);
        } finally {
          setIsLoading(false);
        }
      });

      return () => {
        if (autoCompleteRef.current) {
          // Remover o listener para evitar vazamentos de memória
          google.maps.event.removeListener(listener);
          google.maps.event.clearInstanceListeners(autoCompleteRef.current);
        }
      };
    } catch (error) {
      console.error('Erro ao inicializar o Autocomplete:', error);
      return () => {};
    }
  }, [isLoaded, onPlaceSelect]);

  // Se houver erro, notificar o componente pai
  useEffect(() => {
    if (loadError && onError) {
      onError();
    }
  }, [loadError, onError]);

  if (loadError) {
    return (
      <div>
        <Input placeholder="Serviço de endereço indisponível" disabled className="mb-2 bg-red-50 border-red-200" />
        <p className="text-xs text-red-500 mb-2">
          Não foi possível carregar o serviço de busca automática de endereços.
        </p>
      </div>
    );
  }

  return (
    <div className={`relative ${className || ''}`}>
      <div className="flex items-center">
        <div className="relative flex-1">
          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <Input
            ref={inputRef}
            value={inputValue}
            onChange={handleInputChange}
            placeholder={placeholder}
            disabled={!isLoaded}
            className="pl-10"
          />
        </div>
        {isLoading && (
          <Loader2 className="ml-2 h-5 w-5 animate-spin text-primary" />
        )}
      </div>
      {!isLoaded && (
        <div className="mt-1 text-sm text-gray-500">Carregando serviço de busca de endereços...</div>
      )}
    </div>
  );
}