import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCheckout } from "@/hooks/use-checkout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { useMercadoPago, createCardForm } from "@/lib/mercadopago";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plan, OrderConfirmation } from "@shared/schema";
import {
  CreditCard,
  QrCode,
  Barcode,
  Info,
  Check,
} from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Step3PaymentProps {
  onProcessPayment: () => void;
}

const formSchema = z.object({
  paymentMethod: z.enum(["credit_card", "boleto", "pix"]),
  installments: z.string().min(1),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "Você precisa aceitar os termos de serviço"
  }),
});

type FormValues = z.infer<typeof formSchema>;

export default function Step3Payment({ onProcessPayment }: Step3PaymentProps) {
  const { state, dispatch } = useCheckout();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [cardToken, setCardToken] = useState<string | null>(null);
  const cardFormContainerRef = useRef<HTMLDivElement>(null);
  const { mercadopago, loading: mpLoading } = useMercadoPago();
  const [cardForm, setCardForm] = useState<any>(null);
  
  // Get selected plan details
  const { data: plan } = useQuery<Plan>({
    queryKey: ['/api/plans', state.selectedPlan?.id],
    enabled: !!state.selectedPlan?.id,
  });
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      paymentMethod: state.payment?.paymentMethod || "credit_card",
      installments: state.payment?.installments?.toString() || "1",
      termsAccepted: state.payment?.termsAccepted || false,
    },
  });
  
  // Load Mercado Pago card form
  useEffect(() => {
    if (mercadopago && cardFormContainerRef.current && !cardForm) {
      const newCardForm = createCardForm(mercadopago, 'cardForm', {
        onFormMounted: () => {
          console.log('Card form mounted');
        },
        onSubmit: async (event) => {
          event.preventDefault();
          
          try {
            // In a real application, this would create a card token to send to the server
            // For simplicity in this demo, we'll just set a mock token
            setCardToken('TEST-MOCK-CARD-TOKEN');
            
            // Submit the form
            form.handleSubmit(onSubmit)();
          } catch (error) {
            console.error('Card token error:', error);
            toast({
              title: "Erro de processamento",
              description: "Não foi possível processar o cartão. Verifique os dados e tente novamente.",
              variant: "destructive",
            });
          }
        },
        onError: (error) => {
          console.error('Form error:', error);
        },
      });
      
      setCardForm(newCardForm);
    }
    
    return () => {
      if (cardForm) {
        // Clean up if needed
      }
    };
  }, [mercadopago, cardFormContainerRef.current]);
  
  const onSubmit = async (data: FormValues) => {
    if (!state.selectedPlan || !state.customer) {
      toast({
        title: "Erro",
        description: "Dados incompletos. Por favor, volte e preencha todas as informações.",
        variant: "destructive",
      });
      return;
    }
    
    // Save payment info to state
    dispatch({
      type: 'SET_PAYMENT',
      payload: {
        paymentMethod: data.paymentMethod,
        installments: parseInt(data.installments),
        termsAccepted: data.termsAccepted
      }
    });
    
    // Show processing modal
    onProcessPayment();
    
    try {
      // Submit data to server
      const checkoutData = {
        customer: state.customer,
        payment: {
          planId: state.selectedPlan.id,
          paymentMethod: data.paymentMethod,
          installments: parseInt(data.installments),
          termsAccepted: data.termsAccepted
        },
        token: data.paymentMethod === 'credit_card' ? cardToken : undefined
      };
      
      const response = await apiRequest('POST', '/api/checkout', checkoutData);
      const confirmation: OrderConfirmation = await response.json();
      
      // Store confirmation data for next step
      dispatch({ type: 'SET_CONFIRMATION', payload: confirmation });
      
      // Proceed to confirmation step
      setTimeout(() => {
        dispatch({ type: 'NEXT_STEP' });
      }, 1000); // Short delay to show the processing animation
    } catch (error) {
      console.error('Checkout error:', error);
      toast({
        title: "Erro de processamento",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao processar o pagamento.",
        variant: "destructive",
      });
    }
  };
  
  const handleBack = () => {
    dispatch({ type: 'PREV_STEP' });
  };
  
  return (
    <div className="transition-all duration-500 transform">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-primary mb-4">Forma de Pagamento</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Escolha como deseja realizar o pagamento
        </p>
        
        {state.selectedPlan && (
          <div className="mt-4 inline-block px-6 py-3 bg-green-100 border border-green-300 rounded-lg shadow-sm">
            <p className="text-green-800 font-medium">
              Plano selecionado: <span className="font-bold">{state.selectedPlan.name}</span> - 
              R$ {(state.selectedPlan.price / 100).toFixed(2)}/mês
            </p>
          </div>
        )}
      </div>
      
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem>
                    <Tabs 
                      value={field.value} 
                      onValueChange={field.onChange}
                      className="w-full"
                    >
                      <TabsList className="grid grid-cols-3 mb-6">
                        <TabsTrigger value="credit_card" className="flex items-center">
                          <CreditCard className="mr-2 h-4 w-4" />
                          <span>Cartão</span>
                        </TabsTrigger>
                        <TabsTrigger value="boleto" className="flex items-center">
                          <Barcode className="mr-2 h-4 w-4" />
                          <span>Boleto</span>
                        </TabsTrigger>
                        <TabsTrigger value="pix" className="flex items-center">
                          <QrCode className="mr-2 h-4 w-4" />
                          <span>PIX</span>
                        </TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="credit_card">
                        <div id="cardForm" ref={cardFormContainerRef} className="mb-6 border border-gray-300 rounded-md p-4 bg-gray-50">
                          {mpLoading ? (
                            <div className="py-4 text-center">
                              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                              <p className="mt-2 text-gray-500">Carregando formulário de pagamento...</p>
                            </div>
                          ) : (
                            <div className="text-center text-gray-500 py-6">
                              {!mercadopago && (
                                <div className="flex flex-col items-center">
                                  <Info className="h-12 w-12 text-yellow-500 mb-2" />
                                  <p>Não foi possível carregar o formulário de pagamento.</p>
                                  <p className="text-sm mt-2">Por favor, recarregue a página ou tente novamente mais tarde.</p>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="installments"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Parcelas</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Selecione o número de parcelas" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {plan && [1, 2, 3, 4, 5, 6].map(installment => {
                                    const value = installment.toString();
                                    const valuePerInstallment = (plan.price / 100 / installment).toFixed(2);
                                    return (
                                      <SelectItem key={value} value={value}>
                                        {installment}x de R$ {valuePerInstallment} sem juros
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TabsContent>
                      
                      <TabsContent value="boleto">
                        <div className="bg-gray-50 p-4 rounded-md mb-4">
                          <div className="flex items-start">
                            <Info className="h-5 w-5 text-primary shrink-0 mt-0.5 mr-2" />
                            <div>
                              <p className="text-sm text-gray-600">
                                O boleto será gerado após a finalização do pedido. O prazo de compensação é de até 3 dias úteis.
                              </p>
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="pix">
                        <div className="bg-gray-50 p-4 rounded-md mb-4">
                          <div className="flex items-start">
                            <Info className="h-5 w-5 text-primary shrink-0 mt-0.5 mr-2" />
                            <div>
                              <p className="text-sm text-gray-600">
                                O QR Code do PIX será gerado após a finalização do pedido. O pagamento é processado em instantes.
                              </p>
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </FormItem>
                )}
              />
              
              {/* Plan Summary */}
              {plan && (
                <div className="bg-gray-50 p-4 rounded-md mb-6">
                  <h3 className="font-semibold text-lg mb-3">Resumo do pedido</h3>
                  <div className="flex justify-between mb-2">
                    <span>{plan.name} ({plan.speed} Mbps)</span>
                    <span className="font-semibold">R$ {(plan.price / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span>Taxa de instalação</span>
                    <span className="font-semibold text-green-600">Grátis</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg pt-2 border-t border-gray-300 mt-2">
                    <span>Total</span>
                    <span className="text-primary">R$ {(plan.price / 100).toFixed(2)}</span>
                  </div>
                </div>
              )}
              
              <FormField
                control={form.control}
                name="termsAccepted"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-2 space-y-0">
                    <FormControl>
                      <Checkbox 
                        checked={field.value} 
                        onCheckedChange={field.onChange} 
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm text-gray-600">
                        Li e concordo com os <a href="#" className="text-primary hover:underline">Termos de Serviço</a> e <a href="#" className="text-primary hover:underline">Política de Privacidade</a>.
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <div className="flex justify-between mt-8">
                <Button
                  type="button"
                  variant="outline"
                  className="px-6 py-2 border border-primary text-primary rounded-full font-medium transition-all duration-300 hover:bg-primary hover:text-white"
                  onClick={handleBack}
                >
                  Voltar
                </Button>
                
                <div className="flex flex-col space-y-4">
                  <Button
                    type="submit"
                    className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-semibold shadow-md transition-all duration-300 hover:shadow-lg flex items-center"
                  >
                    <span>Pagar com</span>
                    <img 
                      src="https://seeklogo.com/images/M/mercado-pago-logo-52B7182205-seeklogo.com.png" 
                      alt="Mercado Pago" 
                      className="h-6 ml-2" 
                    />
                  </Button>
                  
                  <div className="text-center">
                    <span className="text-gray-500">ou</span>
                  </div>
                  
                  <a 
                    href="https://link.mercadopago.com.br/altog" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center px-8 py-3 bg-green-600 hover:bg-green-700 text-white rounded-full font-semibold shadow-md transition-all duration-300 hover:shadow-lg"
                  >
                    <span>Pagar Diretamente no Mercado Pago</span>
                  </a>
                </div>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
