import { Link } from "wouter";
import { Facebook, Instagram, Linkedin, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-12 pb-4 mt-12">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <div className="text-center mb-6">
            <Link href="/" className="text-2xl font-bold text-white no-underline">
              ALTO.<span className="text-orange-500">NET</span>
            </Link>
            <p className="mt-2 text-gray-200">Sua conexão com o futuro</p>
          </div>
          
          {/* Área de atendimento */}
          <div className="flex flex-col md:flex-row justify-center items-center mb-6 text-center">
            <div className="flex items-center justify-center mb-2 md:mb-0">
              <MapPin className="text-orange-500 mr-2 h-5 w-5" />
              <p className="text-gray-200 font-medium">
                Área de atendimento:
              </p>
            </div>
            <p className="text-white font-medium ml-0 md:ml-2">
              Capim Grosso, Curral de Pedra, Pereira e região
            </p>
          </div>
          
          {/* Link de pagamento */}
          <div className="flex justify-center mt-4 mb-6">
            <a 
              href="https://link.mercadopago.com.br/altog" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-full font-medium shadow-md transition-all duration-300 hover:shadow-lg"
            >
              <span className="mr-2">Pagar Fatura via</span>
              <img 
                src="https://seeklogo.com/images/M/mercado-pago-logo-52B7182205-seeklogo.com.png" 
                alt="Mercado Pago" 
                className="h-5" 
              />
            </a>
          </div>
          
          <div className="flex justify-center space-x-4 mt-6">
            <a href="#" className="text-white text-xl hover:text-orange-500 transition-colors">
              <Facebook className="h-6 w-6" />
            </a>
            <a href="#" className="text-white text-xl hover:text-orange-500 transition-colors">
              <Instagram className="h-6 w-6" />
            </a>
            <a href="#" className="text-white text-xl hover:text-orange-500 transition-colors">
              <Linkedin className="h-6 w-6" />
            </a>
            <a href="#" className="text-white text-xl hover:text-orange-500 transition-colors">
              <Phone className="h-6 w-6" />
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-6 text-center">
          <p className="text-gray-200">&copy; {new Date().getFullYear()} ALTO.NET - Todos os direitos reservados</p>
        </div>
      </div>
    </footer>
  );
}
