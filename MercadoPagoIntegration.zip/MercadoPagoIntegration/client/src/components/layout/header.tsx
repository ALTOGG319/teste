import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { User, LogOut } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const scrollToSection = (sectionId: string) => {
    // Se estiver na página inicial, rola para a seção
    if (location === '/') {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // Se estiver em outra página, redireciona para a home com o hash da seção
      window.location.href = `/#${sectionId}`;
    }
  };

  return (
    <header className="bg-gradient-to-r from-primary to-blue-900 text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <Link href="/" className="text-2xl font-bold text-white no-underline">
            ALTO.<span className="text-orange-500">NET</span>
          </Link>
          <div className="flex flex-col md:flex-row items-center gap-6">
            <nav>
              <ul className="flex flex-wrap justify-center gap-6">
                <li>
                  <Link href="/" className="text-white font-medium hover:text-orange-500 transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <a 
                    href="#services" 
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection('services');
                    }}
                    className="text-white font-medium hover:text-orange-500 transition-colors cursor-pointer"
                  >
                    Serviços
                  </a>
                </li>
                <li>
                  <a 
                    href="#plans" 
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection('plans');
                    }}
                    className="text-white font-medium hover:text-orange-500 transition-colors cursor-pointer"
                  >
                    Planos
                  </a>
                </li>
                <li>
                  <a 
                    href="#contact" 
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection('contact');
                    }}
                    className="text-white font-medium hover:text-orange-500 transition-colors cursor-pointer"
                  >
                    Contato
                  </a>
                </li>
              </ul>
            </nav>
            
            <div className="ml-0 md:ml-4 mt-4 md:mt-0 flex items-center">
              {user ? (
                <div className="flex items-center space-x-2">
                    <Link href="/profile" className="flex items-center px-3 py-1.5 rounded-md bg-white/10 text-white hover:bg-white/20">
                      <User className="h-4 w-4 mr-2" />
                      Minha Conta
                    </Link>
                    {user?.role === 'admin' && (
                      <Link href="/admin" className="flex items-center px-3 py-1.5 rounded-md bg-orange-500/80 text-white hover:bg-orange-500">
                        Admin
                      </Link>
                    )}
                  </div>
              ) : (
                <Link href="/auth">
                  <Button variant="outline" className="bg-transparent text-white border-white hover:bg-white hover:text-primary">
                    Login / Cadastro
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
