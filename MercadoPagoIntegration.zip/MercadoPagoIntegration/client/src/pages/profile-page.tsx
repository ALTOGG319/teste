import * as React from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User } from "lucide-react";
import { Redirect } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Customer, Payment, Subscription, Plan } from "@shared/schema";
import { getQueryFn } from "@/lib/queryClient";
import {
  Loader2,
  CreditCard,
  Globe,
  Settings,
  LogOut,
  Home,
  FileText,
  RefreshCw,
  CheckCircle2,
  XCircle,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Badge } from "@/components/ui/badge";


export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const [activeTab, setActiveTab] = React.useState("overview");

  if (!user) {
    return <Redirect to="/auth" />;
  }

  // Redirect admin users to admin page
  if (user.role === "admin") {
    return <Redirect to="/admin" />;
  }

  // Buscar dados do cliente
  const { data: customers, isLoading: isLoadingCustomers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar assinaturas
  const { data: subscriptions, isLoading: isLoadingSubscriptions } = useQuery<Subscription[]>({
    queryKey: ["/api/subscriptions"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar pagamentos
  const { data: payments, isLoading: isLoadingPayments } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar planos
  const { data: plans, isLoading: isLoadingPlans } = useQuery<Plan[]>({
    queryKey: ["/api/plans"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const isLoading = isLoadingCustomers || isLoadingSubscriptions || isLoadingPayments || isLoadingPlans;

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Função para obter o nome de um plano baseado no ID
  const getPlanName = (planId: number): string => {
    const plan = plans?.find(p => p.id === planId);
    return plan ? plan.name : `Plano #${planId}`;
  };

  // Dados formatados para exibição
  const activeSubscriptions = subscriptions?.filter(s => s.status === "active") || [];
  const cancelledSubscriptions = subscriptions?.filter(s => s.status === "cancelled") || [];
  const paidPayments = payments?.filter(p => p.status === "paid") || [];
  const pendingPayments = payments?.filter(p => p.status === "pending") || [];

  return (
    <>
      <Header />
      <main className="container py-10">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold">Meu Perfil</h1>
              <p className="text-muted-foreground">Gerencie suas informações e serviços</p>
            </div>
            <Button variant="destructive" size="sm" onClick={handleLogout} disabled={logoutMutation.isPending}>
              {logoutMutation.isPending ? "Saindo..." : "Sair"}
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-[250px_1fr]">
            <Card className="w-full">
              <CardContent className="p-4">
                <div className="flex flex-col items-center space-y-4 border-b pb-6">
                  <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <User className="h-12 w-12" />
                  </div>
                  <div className="space-y-2 text-center w-full px-4">
                    <h2 className="text-xl font-semibold break-words">{user.name}</h2>
                    <p className="text-sm text-muted-foreground break-words">{user.email}</p>
                  </div>
                </div>

                <div className="mt-6">
                  <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <TabsList className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <TabsTrigger value="overview" className="px-2 py-2 text-sm">Visão Geral</TabsTrigger>
                      <TabsTrigger value="services" className="px-2 py-2 text-sm">Meus Serviços</TabsTrigger>
                      <TabsTrigger value="payments" className="px-2 py-2 text-sm">Pagamentos</TabsTrigger>
                      <TabsTrigger value="settings" className="px-2 py-2 text-sm">Configurações</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </CardContent>
            </Card>

            <div>
              <Tabs value={activeTab}>
                <TabsContent value="overview">
                  {/* Visão Geral */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Visão Geral</CardTitle>
                      <CardDescription>
                        Um resumo de seus serviços e pagamentos
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Informações Pessoais */}
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold">Informações Pessoais</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Nome:</p>
                            <p className="font-medium">{user.name}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Email:</p>
                            <p className="font-medium">{user.email}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Usuário:</p>
                            <p className="font-medium">{user.username}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Telefone:</p>
                            <p className="font-medium">{user.phone || "Não informado"}</p>
                          </div>
                        </div>
                      </div>

                      {/* Assinaturas Ativas */}
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold">Assinaturas Ativas</h3>
                        {activeSubscriptions.length === 0 ? (
                          <p className="text-muted-foreground">Você não possui assinaturas ativas.</p>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {activeSubscriptions.map((subscription) => (
                              <Card key={subscription.id} className="border border-border">
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-base">
                                    {getPlanName(subscription.planId)}
                                  </CardTitle>
                                  <CardDescription>
                                    Assinatura #{subscription.id}
                                  </CardDescription>
                                </CardHeader>
                                <CardContent className="pb-2 space-y-2 text-sm">
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Status:</span>
                                    <Badge>Ativo</Badge>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Próximo pagamento:</span>
                                    <span>{format(new Date(subscription.renewalDate), "dd/MM/yyyy", {locale: ptBR})}</span>
                                  </div>
                                </CardContent>
                                <CardFooter>
                                  <Button variant="outline" size="sm" className="w-full">
                                    <FileText className="h-4 w-4 mr-2" />
                                    Ver detalhes
                                  </Button>
                                </CardFooter>
                              </Card>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Últimos Pagamentos */}
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold">Últimos Pagamentos</h3>
                        {payments && payments.length === 0 ? (
                          <p className="text-muted-foreground">Não há histórico de pagamentos.</p>
                        ) : (
                          <div className="overflow-x-auto">
                            <table className="w-full">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-3 px-2">Data</th>
                                  <th className="text-left py-3 px-2">Valor</th>
                                  <th className="text-left py-3 px-2">Método</th>
                                  <th className="text-left py-3 px-2">Status</th>
                                </tr>
                              </thead>
                              <tbody>
                                {payments?.slice(0, 5).map((payment) => (
                                  <tr key={payment.id} className="border-b">
                                    <td className="py-3 px-2">
                                      {payment.paymentDate
                                        ? format(new Date(payment.paymentDate), "dd/MM/yyyy", {locale: ptBR})
                                        : "-"}
                                    </td>
                                    <td className="py-3 px-2">
                                      R$ {(payment.amount / 100).toFixed(2)}
                                    </td>
                                    <td className="py-3 px-2">
                                      {payment.paymentMethod === "credit_card"
                                        ? "Cartão de Crédito"
                                        : payment.paymentMethod === "boleto"
                                        ? "Boleto"
                                        : "PIX"}
                                    </td>
                                    <td className="py-3 px-2">
                                      <Badge
                                        variant={
                                          payment.status === "paid"
                                            ? "default"
                                            : payment.status === "pending"
                                            ? "secondary"
                                            : "destructive"
                                        }
                                      >
                                        {payment.status === "paid"
                                          ? "Pago"
                                          : payment.status === "pending"
                                          ? "Pendente"
                                          : "Falhou"}
                                      </Badge>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="services">
                  <Card>
                    <CardHeader>
                      <CardTitle>Meus Serviços</CardTitle>
                      <CardDescription>
                        Todos os seus serviços e assinaturas contratados
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Assinaturas Ativas */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Assinaturas Ativas</h3>
                        {activeSubscriptions.length === 0 ? (
                          <p className="text-muted-foreground">Você não possui assinaturas ativas.</p>
                        ) : (
                          <div className="grid grid-cols-1 gap-4">
                            {activeSubscriptions.map((subscription) => (
                              <Card key={subscription.id} className="overflow-hidden">
                                <div className="flex flex-col sm:flex-row">
                                  <div className="w-full sm:w-3/4 p-6">
                                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                                        <Globe className="h-6 w-6" />
                                      </div>
                                      <div className="space-y-1">
                                        <h3 className="font-semibold">{getPlanName(subscription.planId)}</h3>
                                        <div className="flex items-center gap-2">
                                          <Badge variant="default">Ativo</Badge>
                                          <span className="text-sm text-muted-foreground">
                                            Assinatura #{subscription.id}
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                                      <div>
                                        <p className="text-sm text-muted-foreground">Data de início:</p>
                                        <p className="font-medium">
                                          {format(new Date(subscription.startDate), "dd/MM/yyyy", {locale: ptBR})}
                                        </p>
                                      </div>
                                      <div>
                                        <p className="text-sm text-muted-foreground">Próxima renovação:</p>
                                        <p className="font-medium">
                                          {format(new Date(subscription.renewalDate), "dd/MM/yyyy", {locale: ptBR})}
                                        </p>
                                      </div>
                                      <div>
                                        <p className="text-sm text-muted-foreground">Renovação automática:</p>
                                        <p className="font-medium">
                                          {subscription.autoRenew ? "Ativada" : "Desativada"}
                                        </p>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="w-full sm:w-1/4 bg-muted p-6 flex flex-col justify-center items-center gap-3">
                                    <Button variant="default" className="w-full">
                                      <RefreshCw className="h-4 w-4 mr-2" />
                                      Renovar
                                    </Button>
                                    <Button variant="outline" className="w-full">
                                      <FileText className="h-4 w-4 mr-2" />
                                      Detalhes
                                    </Button>
                                    <Button variant="ghost" className="w-full text-destructive hover:text-destructive">
                                      <XCircle className="h-4 w-4 mr-2" />
                                      Cancelar
                                    </Button>
                                  </div>
                                </div>
                              </Card>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Assinaturas Canceladas */}
                      {cancelledSubscriptions.length > 0 && (
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold">Assinaturas Canceladas</h3>
                          <div className="grid grid-cols-1 gap-4">
                            {cancelledSubscriptions.map((subscription) => (
                              <Card key={subscription.id} className="overflow-hidden">
                                <div className="flex flex-col sm:flex-row">
                                  <div className="w-full sm:w-3/4 p-6">
                                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                      <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground">
                                        <Globe className="h-6 w-6" />
                                      </div>
                                      <div className="space-y-1">
                                        <h3 className="font-semibold">{getPlanName(subscription.planId)}</h3>
                                        <div className="flex items-center gap-2">
                                          <Badge variant="outline">Cancelado</Badge>
                                          <span className="text-sm text-muted-foreground">
                                            Assinatura #{subscription.id}
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                                      <div>
                                        <p className="text-sm text-muted-foreground">Data de início:</p>
                                        <p className="font-medium">
                                          {format(new Date(subscription.startDate), "dd/MM/yyyy", {locale: ptBR})}
                                        </p>
                                      </div>
                                      <div>
                                        <p className="text-sm text-muted-foreground">Data de cancelamento:</p>
                                        <p className="font-medium">
                                          {subscription.cancelDate
                                            ? format(new Date(subscription.cancelDate), "dd/MM/yyyy", {locale: ptBR})
                                            : "N/A"}
                                        </p>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="w-full sm:w-1/4 bg-muted p-6 flex flex-col justify-center items-center gap-3">
                                    <Button variant="default" className="w-full">
                                      <RefreshCw className="h-4 w-4 mr-2" />
                                      Reativar
                                    </Button>
                                  </div>
                                </div>
                              </Card>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Contratar Novos Serviços */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Contratar Novos Serviços</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <Card>
                            <CardHeader>
                              <CardTitle>Internet Fibra Óptica</CardTitle>
                              <CardDescription>
                                Alta velocidade e estabilidade
                              </CardDescription>
                            </CardHeader>
                            <CardContent>
                              <p className="text-sm text-muted-foreground">
                                Contrate planos de internet via fibra óptica com velocidades de até 400 Mbps.
                              </p>
                            </CardContent>
                            <CardFooter>
                              <Button>Ver Planos de Fibra</Button>
                            </CardFooter>
                          </Card>
                          <Card>
                            <CardHeader>
                              <CardTitle>Internet via Rádio</CardTitle>
                              <CardDescription>
                                Ideal para áreas rurais
                              </CardDescription>
                            </CardHeader>
                            <CardContent>
                              <p className="text-sm text-muted-foreground">
                                Solução para áreas onde a fibra óptica ainda não está disponível.
                              </p>
                            </CardContent>
                            <CardFooter>
                              <Button>Ver Planos de Rádio</Button>
                            </CardFooter>
                          </Card>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="payments">
                  <Card>
                    <CardHeader>
                      <CardTitle>Pagamentos</CardTitle>
                      <CardDescription>
                        Histórico de pagamentos e faturas
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Pagamentos Pendentes */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Pagamentos Pendentes</h3>
                        {pendingPayments.length === 0 ? (
                          <p className="text-muted-foreground">Não há pagamentos pendentes.</p>
                        ) : (
                          <div className="grid grid-cols-1 gap-4">
                            {pendingPayments.map((payment) => (
                              <Card key={payment.id} className="overflow-hidden">
                                <div className="flex flex-col sm:flex-row">
                                  <div className="w-full sm:w-3/4 p-6">
                                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                                      <div className="h-12 w-12 rounded-full bg-secondary/10 flex items-center justify-center text-secondary">
                                        <AlertCircle className="h-6 w-6" />
                                      </div>
                                      <div className="space-y-1">
                                        <h3 className="font-semibold">Fatura #{payment.id}</h3>
                                        <div className="flex items-center gap-2">
                                          <Badge variant="secondary">Pendente</Badge>
                                          <span className="text-sm text-muted-foreground">
                                            Vencimento: {format(new Date(payment.dueDate), "dd/MM/yyyy", {locale: ptBR})}
                                          </span>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                                      <div>
                                        <p className="text-sm text-muted-foreground">Valor:</p>
                                        <p className="font-medium">
                                          R$ {(payment.amount / 100).toFixed(2)}
                                        </p>
                                      </div>
                                      <div>
                                        <p className="text-sm text-muted-foreground">Método:</p>
                                        <p className="font-medium">
                                          {payment.paymentMethod === "credit_card"
                                            ? "Cartão de Crédito"
                                            : payment.paymentMethod === "boleto"
                                            ? "Boleto"
                                            : "PIX"}
                                        </p>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="w-full sm:w-1/4 bg-muted p-6 flex flex-col justify-center items-center gap-3">
                                    <Button variant="default" className="w-full">
                                      <CreditCard className="h-4 w-4 mr-2" />
                                      Pagar Agora
                                    </Button>
                                    {payment.receiptUrl && (
                                      <Button variant="outline" className="w-full" asChild>
                                        <a href={payment.receiptUrl} target="_blank" rel="noopener noreferrer">
                                          <FileText className="h-4 w-4 mr-2" />
                                          Ver Boleto/PIX
                                        </a>
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </Card>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Histórico de Pagamentos */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Histórico de Pagamentos</h3>
                        {paidPayments.length === 0 ? (
                          <p className="text-muted-foreground">Não há histórico de pagamentos.</p>
                        ) : (
                          <div className="overflow-x-auto">
                            <table className="w-full">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-3 px-2">ID</th>
                                  <th className="text-left py-3 px-2">Data</th>
                                  <th className="text-left py-3 px-2">Valor</th>
                                  <th className="text-left py-3 px-2">Método</th>
                                  <th className="text-left py-3 px-2">Status</th>
                                  <th className="text-right py-3 px-2">Ação</th>
                                </tr>
                              </thead>
                              <tbody>
                                {paidPayments.map((payment) => (
                                  <tr key={payment.id} className="border-b">
                                    <td className="py-3 px-2">#{payment.id}</td>
                                    <td className="py-3 px-2">
                                      {payment.paymentDate
                                        ? format(new Date(payment.paymentDate), "dd/MM/yyyy", {locale: ptBR})
                                        : "-"}
                                    </td>
                                    <td className="py-3 px-2">
                                      R$ {(payment.amount / 100).toFixed(2)}
                                    </td>
                                    <td className="py-3 px-2">
                                      {payment.paymentMethod === "credit_card"
                                        ? "Cartão de Crédito"
                                        : payment.paymentMethod === "boleto"
                                        ? "Boleto"
                                        : "PIX"}
                                    </td>
                                    <td className="py-3 px-2">
                                      <Badge
                                        variant={
                                          payment.status === "paid"
                                            ? "default"
                                            : payment.status === "pending"
                                            ? "secondary"
                                            : "destructive"
                                        }
                                      >
                                        {payment.status === "paid"
                                          ? "Pago"
                                          : payment.status === "pending"
                                          ? "Pendente"
                                          : "Falhou"}
                                      </Badge>
                                    </td>
                                    <td className="py-3 px-2 text-right">
                                      {payment.receiptUrl ? (
                                        <Button variant="outline" size="sm" asChild>
                                          <a href={payment.receiptUrl} target="_blank" rel="noopener noreferrer">
                                            <FileText className="h-4 w-4 mr-2" />
                                            Recibo
                                          </a>
                                        </Button>
                                      ) : (
                                        <Button variant="outline" size="sm" disabled>
                                          <FileText className="h-4 w-4 mr-2" />
                                          Recibo
                                        </Button>
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="settings">
                  <Card>
                    <CardHeader>
                      <CardTitle>Configurações da Conta</CardTitle>
                      <CardDescription>
                        Gerencie suas preferências e informações pessoais
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Informações Pessoais */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Informações Pessoais</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Nome</label>
                            <input
                              type="text"
                              defaultValue={user.name}
                              className="w-full p-2 border rounded-md"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Email</label>
                            <input
                              type="email"
                              defaultValue={user.email}
                              className="w-full p-2 border rounded-md"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Telefone</label>
                            <input
                              type="tel"
                              defaultValue={user.phone || ""}
                              className="w-full p-2 border rounded-md"
                            />
                          </div>
                        </div>
                        <Button>Salvar Alterações</Button>
                      </div>

                      {/* Alterar Senha */}
                      <div className="space-y-4 pt-4 border-t">
                        <h3 className="text-lg font-semibold">Alterar Senha</h3>
                        <div className="grid grid-cols-1 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Senha Atual</label>
                            <input
                              type="password"
                              className="w-full p-2 border rounded-md"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Nova Senha</label>
                            <input
                              type="password"
                              className="w-full p-2 border rounded-md"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Confirmar Nova Senha</label>
                            <input
                              type="password"
                              className="w-full p-2 border rounded-md"
                            />
                          </div>
                        </div>
                        <Button>Alterar Senha</Button>
                      </div>

                      {/* Preferências de Notificação */}
                      <div className="space-y-4 pt-4 border-t">
                        <h3 className="text-lg font-semibold">Preferências de Notificação</h3>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="email-notifications" className="h-4 w-4" defaultChecked />
                            <label htmlFor="email-notifications">Receber notificações por email</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="sms-notifications" className="h-4 w-4" defaultChecked />
                            <label htmlFor="sms-notifications">Receber notificações por SMS</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="promo-notifications" className="h-4 w-4" defaultChecked />
                            <label htmlFor="promo-notifications">Receber ofertas e promoções</label>
                          </div>
                        </div>
                        <Button>Salvar Preferências</Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}