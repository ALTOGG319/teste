import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { Customer, Payment, Subscription } from "@shared/schema";
import { getQueryFn } from "@/lib/queryClient";
import { Loader2, User, Calendar, CreditCard, HelpCircle, LogOut } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Badge } from "@/components/ui/badge";

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const [activeTab, setActiveTab] = useState("assinaturas");

  // Buscar assinaturas do cliente
  const { data: subscriptions, isLoading: isLoadingSubscriptions } = useQuery<Subscription[]>({
    queryKey: ["/api/subscriptions"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user,
  });

  // Buscar pagamentos do cliente
  const { data: payments, isLoading: isLoadingPayments } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user,
  });

  // Buscar informações do cliente
  const { data: customers, isLoading: isLoadingCustomers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user,
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (!user) {
    return null;
  }

  const isLoading = isLoadingSubscriptions || isLoadingPayments || isLoadingCustomers;

  return (
    <>
      <Header />
      <main className="container py-10">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold">Minha Conta</h1>
              <p className="text-muted-foreground">Gerencie seus serviços e informações</p>
            </div>
            <Button variant="destructive" size="sm" onClick={handleLogout} disabled={logoutMutation.isPending}>
              <LogOut className="h-4 w-4 mr-2" />
              {logoutMutation.isPending ? "Saindo..." : "Sair"}
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-[250px_1fr]">
            {/* Menu Lateral */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col gap-6">
                  <div className="flex flex-col items-center space-y-2 border-b pb-4">
                    <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <User className="h-10 w-10" />
                    </div>
                    <div className="space-y-1 text-center">
                      <h2 className="text-xl font-semibold">{user.name}</h2>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm font-medium mb-2">Menu</p>
                    <Tabs value={activeTab} onValueChange={setActiveTab} orientation="vertical" className="w-full">
                      <TabsList className="flex flex-col h-auto bg-transparent gap-1">
                        <TabsTrigger value="assinaturas" className="justify-start w-full">
                          <Calendar className="h-4 w-4 mr-2" />
                          Assinaturas
                        </TabsTrigger>
                        <TabsTrigger value="pagamentos" className="justify-start w-full">
                          <CreditCard className="h-4 w-4 mr-2" />
                          Pagamentos
                        </TabsTrigger>
                        <TabsTrigger value="dados" className="justify-start w-full">
                          <User className="h-4 w-4 mr-2" />
                          Meus Dados
                        </TabsTrigger>
                        <TabsTrigger value="suporte" className="justify-start w-full">
                          <HelpCircle className="h-4 w-4 mr-2" />
                          Suporte
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Conteúdo */}
            <div>
              {isLoading ? (
                <Card>
                  <CardContent className="flex items-center justify-center min-h-[300px]">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </CardContent>
                </Card>
              ) : (
                <Tabs value={activeTab} className="w-full">
                  <TabsContent value="assinaturas" className="mt-0">
                    <Card>
                      <CardHeader>
                        <CardTitle>Minhas Assinaturas</CardTitle>
                        <CardDescription>
                          Gerencie seus planos de internet ativos e cancelados
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {subscriptions && subscriptions.length > 0 ? (
                          <div className="grid gap-4">
                            {subscriptions.map((subscription) => (
                              <div
                                key={subscription.id}
                                className="border rounded-lg p-4 grid md:grid-cols-[1fr_auto] gap-4"
                              >
                                <div className="space-y-2">
                                  <div className="flex items-start justify-between">
                                    <div>
                                      <h3 className="font-semibold">Plano Fibra 200</h3>
                                      <p className="text-sm text-muted-foreground">
                                        Assinatura #{subscription.id}
                                      </p>
                                    </div>
                                    <Badge
                                      variant={
                                        subscription.status === "active"
                                          ? "success"
                                          : subscription.status === "suspended"
                                          ? "warning"
                                          : "destructive"
                                      }
                                    >
                                      {subscription.status === "active"
                                        ? "Ativo"
                                        : subscription.status === "suspended"
                                        ? "Suspenso"
                                        : "Cancelado"}
                                    </Badge>
                                  </div>
                                  <div className="grid grid-cols-2 gap-2 text-sm">
                                    <div>
                                      <p className="text-muted-foreground">Início</p>
                                      <p>
                                        {format(new Date(subscription.startDate), "dd/MM/yyyy", { locale: ptBR })}
                                      </p>
                                    </div>
                                    <div>
                                      <p className="text-muted-foreground">Próxima renovação</p>
                                      <p>
                                        {format(new Date(subscription.renewalDate), "dd/MM/yyyy", { locale: ptBR })}
                                      </p>
                                    </div>
                                    <div>
                                      <p className="text-muted-foreground">Auto-renovação</p>
                                      <p>{subscription.autoRenew ? "Sim" : "Não"}</p>
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-end flex-col justify-end gap-2">
                                  <Button size="sm" disabled={subscription.status !== "active"}>
                                    Gerenciar
                                  </Button>
                                  {subscription.status === "active" && (
                                    <Button size="sm" variant="outline">
                                      Cancelar
                                    </Button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                              <Calendar className="h-10 w-10 text-muted-foreground" />
                            </div>
                            <h3 className="mt-4 text-lg font-semibold">Sem assinaturas</h3>
                            <p className="mt-2 text-sm text-muted-foreground">
                              Você ainda não possui assinaturas. Escolha um plano para começar.
                            </p>
                            <Button className="mt-4">Ver planos</Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="pagamentos" className="mt-0">
                    <Card>
                      <CardHeader>
                        <CardTitle>Meus Pagamentos</CardTitle>
                        <CardDescription>
                          Histórico de pagamentos e faturas
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {payments && payments.length > 0 ? (
                          <div className="overflow-x-auto">
                            <table className="w-full">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-3 px-2">Data</th>
                                  <th className="text-left py-3 px-2">Descrição</th>
                                  <th className="text-left py-3 px-2">Valor</th>
                                  <th className="text-left py-3 px-2">Status</th>
                                  <th className="text-left py-3 px-2"></th>
                                </tr>
                              </thead>
                              <tbody>
                                {payments.map((payment) => (
                                  <tr key={payment.id} className="border-b">
                                    <td className="py-3 px-2">
                                      {payment.paymentDate 
                                        ? format(new Date(payment.paymentDate), "dd/MM/yyyy", { locale: ptBR })
                                        : format(new Date(payment.createdAt), "dd/MM/yyyy", { locale: ptBR })}
                                    </td>
                                    <td className="py-3 px-2">
                                      Plano Internet
                                    </td>
                                    <td className="py-3 px-2">
                                      R$ {(payment.amount / 100).toFixed(2)}
                                    </td>
                                    <td className="py-3 px-2">
                                      <Badge
                                        variant={
                                          payment.status === "paid"
                                            ? "success"
                                            : payment.status === "pending"
                                            ? "warning"
                                            : "destructive"
                                        }
                                      >
                                        {payment.status === "paid"
                                          ? "Pago"
                                          : payment.status === "pending"
                                          ? "Pendente"
                                          : "Falhou"}
                                      </Badge>
                                    </td>
                                    <td className="py-3 px-2 text-right">
                                      {payment.receiptUrl && (
                                        <Button size="sm" variant="outline" asChild>
                                          <a href={payment.receiptUrl} target="_blank" rel="noopener noreferrer">
                                            Recibo
                                          </a>
                                        </Button>
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-muted">
                              <CreditCard className="h-10 w-10 text-muted-foreground" />
                            </div>
                            <h3 className="mt-4 text-lg font-semibold">Sem pagamentos</h3>
                            <p className="mt-2 text-sm text-muted-foreground">
                              Você ainda não possui histórico de pagamentos.
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="dados" className="mt-0">
                    <Card>
                      <CardHeader>
                        <CardTitle>Meus Dados</CardTitle>
                        <CardDescription>
                          Visualize e edite suas informações pessoais
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-6">
                          <div className="space-y-2">
                            <h3 className="text-lg font-semibold">Informações da Conta</h3>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Nome</p>
                                <p className="font-medium">{user.name}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Nome de Usuário</p>
                                <p className="font-medium">{user.username}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">E-mail</p>
                                <p className="font-medium">{user.email}</p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Telefone</p>
                                <p className="font-medium">{user.phone || "Não informado"}</p>
                              </div>
                            </div>
                          </div>

                          {customers && customers.length > 0 && (
                            <div className="space-y-2">
                              <h3 className="text-lg font-semibold">Endereços Cadastrados</h3>
                              <div className="grid gap-4">
                                {customers.map((customer) => (
                                  <div key={customer.id} className="border rounded-lg p-4">
                                    <div className="grid gap-4 md:grid-cols-2">
                                      <div className="space-y-1">
                                        <p className="text-sm text-muted-foreground">Nome</p>
                                        <p className="font-medium">{customer.name}</p>
                                      </div>
                                      <div className="space-y-1">
                                        <p className="text-sm text-muted-foreground">CPF/CNPJ</p>
                                        <p className="font-medium">{customer.documentNumber}</p>
                                      </div>
                                      <div className="space-y-1">
                                        <p className="text-sm text-muted-foreground">E-mail</p>
                                        <p className="font-medium">{customer.email}</p>
                                      </div>
                                      <div className="space-y-1">
                                        <p className="text-sm text-muted-foreground">Telefone</p>
                                        <p className="font-medium">{customer.phone}</p>
                                      </div>
                                      <div className="col-span-2 space-y-1">
                                        <p className="text-sm text-muted-foreground">Endereço</p>
                                        <p className="font-medium">
                                          {customer.street}, {customer.number}
                                          {customer.complement ? `, ${customer.complement}` : ""} - {customer.neighborhood}, {customer.city} - CEP: {customer.zipCode}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex justify-end">
                            <Button>Editar Informações</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="suporte" className="mt-0">
                    <Card>
                      <CardHeader>
                        <CardTitle>Suporte</CardTitle>
                        <CardDescription>
                          Precisa de ajuda? Entre em contato conosco
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-6">
                          <div className="grid gap-6 md:grid-cols-2">
                            <Card>
                              <CardHeader className="pb-2">
                                <CardTitle className="text-lg">Atendimento Telefônico</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <p className="text-sm text-muted-foreground">
                                  De segunda a sexta, das 8h às 20h
                                </p>
                                <p className="text-lg font-semibold mt-2">(74) 99999-9999</p>
                              </CardContent>
                            </Card>
                            <Card>
                              <CardHeader className="pb-2">
                                <CardTitle className="text-lg">WhatsApp</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <p className="text-sm text-muted-foreground">
                                  Atendimento 24 horas por dia
                                </p>
                                <p className="text-lg font-semibold mt-2">(74) 99999-9999</p>
                              </CardContent>
                            </Card>
                            <Card>
                              <CardHeader className="pb-2">
                                <CardTitle className="text-lg">E-mail</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <p className="text-sm text-muted-foreground">
                                  Respondemos em até 24 horas
                                </p>
                                <p className="text-lg font-semibold mt-2">contato@jonatasnet.com.br</p>
                              </CardContent>
                            </Card>
                            <Card>
                              <CardHeader className="pb-2">
                                <CardTitle className="text-lg">Endereço</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <p className="text-sm text-muted-foreground">
                                  Visite nossa loja física
                                </p>
                                <p className="text-lg font-semibold mt-2">Av. Principal, 123 - Centro, Capim Grosso - BA</p>
                              </CardContent>
                            </Card>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}