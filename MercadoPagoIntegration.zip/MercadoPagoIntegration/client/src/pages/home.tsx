import { Link } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { useQuery } from "@tanstack/react-query";
import { Plan } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckIcon, Gauge, MapPin, ShieldCheckIcon, WifiIcon } from "lucide-react";

export default function Home() {
  const { data: plans, isLoading } = useQuery<Plan[]>({
    queryKey: ['/api/plans'],
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative flex items-center justify-center text-center py-24 bg-gradient-to-r from-primary to-blue-900 text-white">
        <div className="absolute inset-0 bg-black/60 z-0"></div>
        <div className="container px-4 mx-auto relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Internet de Alta Velocidade para sua Empresa</h1>
          <p className="text-xl max-w-3xl mx-auto mb-3">
            Conectividade rápida, estável e segura com a melhor infraestrutura da região.
          </p>
          
          <div className="flex items-center justify-center mb-8">
            <MapPin className="text-secondary mr-2 h-5 w-5" />
            <p className="text-lg font-medium text-gray-200">
              Atendemos <span className="text-white font-semibold">Capim Grosso, Curral de Pedra, Pereira e região</span>
            </p>
          </div>

          <div className="flex justify-center">
            <Link href="/checkout">
              <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-6 rounded-full">
                Solicitar Orçamento
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-primary mb-4">Nossos Serviços</h2>
            <p className="text-xl text-gray-600">Soluções personalizadas para atender sua demanda</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg text-center transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
              <div className="mb-6 text-5xl text-primary flex justify-center">
                <Gauge size={64} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Internet Fibra Óptica</h3>
              <p className="text-gray-600">Velocidades de até 1Gbps com tecnologia 100% fibra óptica.</p>
            </div>
            
            <div className="bg-gray-50 p-8 rounded-lg text-center transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
              <div className="mb-6 text-5xl text-primary flex justify-center">
                <WifiIcon size={64} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Wi-Fi Empresarial</h3>
              <p className="text-gray-600">Cobertura otimizada para ambientes corporativos.</p>
            </div>
            
            <div className="bg-gray-50 p-8 rounded-lg text-center transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
              <div className="mb-6 text-5xl text-primary flex justify-center">
                <ShieldCheckIcon size={64} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Segurança Digital</h3>
              <p className="text-gray-600">Proteção avançada contra ameaças virtuais.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Plans Section */}
      <section id="plans" className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-primary mb-4">Nossos Planos</h2>
            <p className="text-xl text-gray-600">Escolha o plano ideal para o seu negócio</p>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <>
              {/* Planos de Fibra Óptica */}
              <div className="mb-12">
                <h3 className="text-2xl font-bold text-primary mb-6 text-center">Internet Fibra Óptica</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                  {plans?.filter(plan => plan.name.includes('Fibra')).map((plan) => (
                    <Card key={plan.id} className={`overflow-hidden transition-all duration-300 hover:shadow-xl ${plan.isPopular ? 'border-2 border-secondary md:scale-105' : 'border hover:border-secondary'}`}>
                      <CardHeader className={`pb-4 ${plan.isPopular ? 'bg-gradient-to-r from-secondary to-orange-600' : 'bg-gradient-to-r from-primary to-blue-900'} text-white relative`}>
                        {plan.isPopular && (
                          <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-500 hover:bg-yellow-600 text-white">
                            MAIS POPULAR
                          </Badge>
                        )}
                        <CardTitle className="text-xl text-center">{plan.name}</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-6">
                        <div className="text-center mb-6">
                          <span className="text-4xl font-bold text-primary">
                            R$ {(plan.price / 100).toFixed(0)}
                          </span>
                          <span className="text-gray-800">/mês</span>
                        </div>
                        <ul className="space-y-3 mb-6">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex items-start">
                              <CheckIcon className="h-5 w-5 text-green-500 shrink-0 mt-0.5 mr-2" />
                              <span className="text-gray-900">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Link href="/checkout" className="w-full">
                          <Button className={`w-full text-white font-medium ${plan.isPopular ? 'bg-orange-500 hover:bg-orange-600' : 'bg-blue-600 hover:bg-blue-700'}`}>
                            Selecionar
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
              
              {/* Planos de Internet via Rádio */}
              <div>
                <h3 className="text-2xl font-bold text-primary mb-6 text-center">Internet via Rádio</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                  {plans?.filter(plan => plan.name.includes('Rádio')).map((plan) => (
                    <Card key={plan.id} className="overflow-hidden transition-all duration-300 hover:shadow-xl border hover:border-secondary">
                      <CardHeader className="pb-4 bg-gradient-to-r from-primary to-blue-900 text-white">
                        <CardTitle className="text-xl text-center">{plan.name}</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-6">
                        <div className="text-center mb-6">
                          <span className="text-4xl font-bold text-primary">
                            R$ {(plan.price / 100).toFixed(0)}
                          </span>
                          <span className="text-gray-800">/mês</span>
                        </div>
                        <ul className="space-y-3 mb-6">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex items-start">
                              <CheckIcon className="h-5 w-5 text-green-500 shrink-0 mt-0.5 mr-2" />
                              <span className="text-gray-900">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Link href="/checkout" className="w-full">
                          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium">
                            Selecionar
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </section>
      
      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-primary mb-4">Entre em Contato</h2>
            <p className="text-xl text-gray-600">Estamos prontos para atender sua empresa</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-primary text-2xl">Informações de Contato</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">E-mail:</p>
                    <p className="text-gray-800">jonatasaraujorios1999@gmail.com</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Telefone:</p>
                    <p className="text-gray-800">(74) 99135-4652</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Atendimento:</p>
                    <p className="text-gray-800">Segunda a Sexta, 8h às 18h</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-primary text-2xl">Envie uma Mensagem</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                    <input
                      id="name"
                      type="text"
                      placeholder="Seu Nome"
                      className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-gray-900"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                    <input
                      id="email"
                      type="email"
                      placeholder="Seu E-mail"
                      className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-gray-900"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Mensagem</label>
                    <textarea
                      id="message"
                      placeholder="Sua Mensagem"
                      rows={5}
                      className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-gray-900"
                    ></textarea>
                  </div>
                  <Button className="bg-orange-500 hover:bg-orange-600 w-full text-white font-medium">
                    Enviar Mensagem
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}
