import { useState, useEffect } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import CheckoutProgress from "@/components/checkout/checkout-progress";
import Step1PlanSelection from "@/components/checkout/step-1-plan-selection";
import Step2PersonalInfo from "@/components/checkout/step-2-personal-info";
import Step3Payment from "@/components/checkout/step-3-payment";
import Step4Confirmation from "@/components/checkout/step-4-confirmation";
import PaymentProcessingModal from "@/components/checkout/payment-processing-modal";
import { useCheckout } from "@/hooks/use-checkout";
import { useQuery } from "@tanstack/react-query";

export default function Checkout() {
  const { state, dispatch } = useCheckout();
  const [showProcessingModal, setShowProcessingModal] = useState(false);
  
  // Fetch plans if they aren't already loaded
  const { data: plans } = useQuery({
    queryKey: ['/api/plans'],
  });
  
  // If checkout step is 1 and we have plans, select the first one by default
  useEffect(() => {
    if (state.step === 1 && plans && plans.length > 0 && !state.selectedPlan) {
      const popularPlan = plans.find(plan => plan.isPopular) || plans[0];
      dispatch({ type: 'SET_PLAN', payload: popularPlan });
    }
  }, [plans, state.step, state.selectedPlan, dispatch]);
  
  // Show processing modal when needed
  useEffect(() => {
    if (showProcessingModal) {
      // Auto-hide after 3 seconds in this demo
      const timer = setTimeout(() => {
        setShowProcessingModal(false);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [showProcessingModal]);
  
  const handleProcessPayment = () => {
    setShowProcessingModal(true);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          <CheckoutProgress currentStep={state.step} />
          
          {state.step === 1 && <Step1PlanSelection />}
          {state.step === 2 && <Step2PersonalInfo />}
          {state.step === 3 && <Step3Payment onProcessPayment={handleProcessPayment} />}
          {state.step === 4 && <Step4Confirmation />}
        </div>
      </main>
      
      <PaymentProcessingModal isOpen={showProcessingModal} />
      
      <Footer />
    </div>
  );
}
