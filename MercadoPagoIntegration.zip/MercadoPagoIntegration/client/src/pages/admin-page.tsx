import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { Customer, Payment, Subscription, Plan, User } from "@shared/schema";
import { getQueryFn } from "@/lib/queryClient";
import { 
  Loader2, 
  User as UserIcon, 
  Users, 
  CreditCard, 
  LayoutDashboard, 
  Settings, 
  LogOut,
  Globe,
  BarChart3,
  Package,
  Search,
  Edit,
  Trash2
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Redirect } from "wouter";

// Componente para o gráfico de barras
function BarChartComponent({ data }: { data: { label: string; value: number }[] }) {
  const maxValue = Math.max(...data.map(item => item.value));

  return (
    <div className="w-full space-y-2">
      {data.map((item, index) => (
        <div key={index} className="space-y-1">
          <div className="flex justify-between text-sm">
            <span>{item.label}</span>
            <span>R$ {item.value.toFixed(2)}</span>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div 
              className="h-full bg-primary"
              style={{ width: `${(item.value / maxValue) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function AdminPage() {
  const { user, logoutMutation } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [searchTerm, setSearchTerm] = useState("");

  // Verificar se o usuário tem permissão de administrador
  if (!user || user.role !== "admin") {
    return <Redirect to="/" />;
  }

  // Buscar todos os usuários
  const { data: users, isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar todos os clientes
  const { data: customers, isLoading: isLoadingCustomers } = useQuery<Customer[]>({
    queryKey: ["/api/admin/customers"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar todas as assinaturas
  const { data: subscriptions, isLoading: isLoadingSubscriptions } = useQuery<Subscription[]>({
    queryKey: ["/api/admin/subscriptions"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar todos os pagamentos
  const { data: payments, isLoading: isLoadingPayments } = useQuery<Payment[]>({
    queryKey: ["/api/admin/payments"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar todos os planos
  const { data: plans, isLoading: isLoadingPlans } = useQuery<Plan[]>({
    queryKey: ["/api/plans"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Buscar dados do dashboard
  const { data: dashboardData, isLoading: isLoadingDashboard } = useQuery<any>({
    queryKey: ["/api/admin/dashboard"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const isLoading = 
    isLoadingUsers || 
    isLoadingCustomers || 
    isLoadingSubscriptions || 
    isLoadingPayments || 
    isLoadingPlans || 
    isLoadingDashboard;

  // Função para filtrar itens baseados no termo de busca
  const filterItems = <T extends { id: number; name?: string; email?: string }>(
    items: T[] | undefined, 
    searchTerm: string
  ): T[] => {
    if (!items) return [];
    if (!searchTerm.trim()) return items;

    return items.filter(item => 
      (item.name && item.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.email && item.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
      String(item.id).includes(searchTerm)
    );
  };

  // Mocks para dados de demonstração
  const mockDashboardData = {
    totalRevenue: 8750.00,
    activeSubscriptions: 68,
    totalCustomers: customers?.length || 42,
    recentPayments: payments?.slice(0, 5) || [],
    revenueByMonth: [
      { label: 'Jan', value: 5200.00 },
      { label: 'Fev', value: 6100.00 },
      { label: 'Mar', value: 5800.00 },
      { label: 'Abr', value: 6300.00 },
      { label: 'Mai', value: 6500.00 },
      { label: 'Jun', value: 7200.00 },
    ],
    planDistribution: [
      { label: 'Fibra 100', value: 12 },
      { label: 'Fibra 200', value: 24 },
      { label: 'Fibra 400', value: 16 },
      { label: 'Rádio 10', value: 8 },
      { label: 'Rádio 30', value: 8 }
    ]
  };

  const dashboardInfo = dashboardData || mockDashboardData;

  return (
    <>
      <Header />
      <main className="container py-10">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold">Painel Administrativo</h1>
              <p className="text-muted-foreground">Gerencie usuários, clientes e serviços</p>
            </div>
            <Button variant="destructive" size="sm" onClick={handleLogout} disabled={logoutMutation.isPending}>
              <LogOut className="h-4 w-4 mr-2" />
              {logoutMutation.isPending ? "Saindo..." : "Sair"}
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-[250px_1fr]">
            {/* Menu Lateral */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col gap-6">
                  <div className="flex flex-col items-center space-y-2 border-b pb-4">
                    <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <UserIcon className="h-10 w-10" />
                    </div>
                    <div className="space-y-1 text-center">
                      <h2 className="text-xl font-semibold">{user.name}</h2>
                      <Badge>Administrador</Badge>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <p className="text-sm font-medium mb-2">Menu</p>
                    <Tabs value={activeTab} onValueChange={setActiveTab} orientation="vertical" className="w-full">
                      <TabsList className="flex flex-col h-auto bg-transparent gap-1">
                        <TabsTrigger value="dashboard" className="justify-start w-full">
                          <LayoutDashboard className="h-4 w-4 mr-2" />
                          Dashboard
                        </TabsTrigger>
                        <TabsTrigger value="users" className="justify-start w-full">
                          <Users className="h-4 w-4 mr-2" />
                          Usuários
                        </TabsTrigger>
                        <TabsTrigger value="customers" className="justify-start w-full">
                          <UserIcon className="h-4 w-4 mr-2" />
                          Clientes
                        </TabsTrigger>
                        <TabsTrigger value="subscriptions" className="justify-start w-full">
                          <Globe className="h-4 w-4 mr-2" />
                          Assinaturas
                        </TabsTrigger>
                        <TabsTrigger value="payments" className="justify-start w-full">
                          <CreditCard className="h-4 w-4 mr-2" />
                          Pagamentos
                        </TabsTrigger>
                        <TabsTrigger value="plans" className="justify-start w-full">
                          <Package className="h-4 w-4 mr-2" />
                          Planos
                        </TabsTrigger>
                        <TabsTrigger value="settings" className="justify-start w-full">
                          <Settings className="h-4 w-4 mr-2" />
                          Configurações
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Conteúdo */}
            <div>
              {isLoading ? (
                <Card>
                  <CardContent className="flex items-center justify-center min-h-[300px]">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </CardContent>
                </Card>
              ) : (
                <Tabs value={activeTab} className="w-full">
                  <TabsContent value="dashboard" className="mt-0">
                    <Card>
                      <CardHeader>
                        <CardTitle>Dashboard</CardTitle>
                        <CardDescription>
                          Visão geral do desempenho do negócio
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-8">
                        {/* Métricas principais */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium text-muted-foreground">
                                Faturamento Total
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                R$ {dashboardInfo.totalRevenue.toFixed(2)}
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                +5.2% em relação ao mês anterior
                              </p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium text-muted-foreground">
                                Assinaturas Ativas
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                {dashboardInfo.activeSubscriptions}
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                +3 novos clientes este mês
                              </p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm font-medium text-muted-foreground">
                                Total de Clientes
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">
                                {dashboardInfo.totalCustomers}
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                Crescimento de 8% no trimestre
                              </p>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Gráficos */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Receita Mensal</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <BarChartComponent data={dashboardInfo.revenueByMonth} />
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg">Distribuição por Plano</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-4">
                                {dashboardInfo.planDistribution.map((item: any, index: number) => (
                                  <div key={index} className="flex items-center gap-2">
                                    <div className="w-4 h-4 rounded-full bg-primary" />
                                    <div className="text-sm">{item.label}</div>
                                    <div className="text-sm ml-auto font-medium">{item.value} clientes</div>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Pagamentos Recentes */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Pagamentos Recentes</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="overflow-x-auto">
                              <table className="w-full text-sm">
                                <thead>
                                  <tr className="border-b">
                                    <th className="text-left py-3 px-2">ID</th>
                                    <th className="text-left py-3 px-2">Cliente</th>
                                    <th className="text-left py-3 px-2">Data</th>
                                    <th className="text-left py-3 px-2">Valor</th>
                                    <th className="text-left py-3 px-2">Status</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {dashboardInfo.recentPayments.map((payment: any) => (
                                    <tr key={payment.id} className="border-b">
                                      <td className="py-3 px-2">#{payment.id}</td>
                                      <td className="py-3 px-2">Cliente #{payment.customerId}</td>
                                      <td className="py-3 px-2">
                                        {payment.paymentDate 
                                          ? format(new Date(payment.paymentDate), "dd/MM/yyyy", {locale: ptBR})
                                          : format(new Date(payment.createdAt), "dd/MM/yyyy", {locale: ptBR})}
                                      </td>
                                      <td className="py-3 px-2">R$ {(payment.amount / 100).toFixed(2)}</td>
                                      <td className="py-3 px-2">
                                        <Badge
                                          variant={
                                            payment.status === "paid"
                                              ? "default"
                                              : payment.status === "pending"
                                              ? "secondary"
                                              : "destructive"
                                          }
                                        >
                                          {payment.status === "paid"
                                            ? "Pago"
                                            : payment.status === "pending"
                                            ? "Pendente"
                                            : "Falhou"}
                                        </Badge>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </CardContent>
                        </Card>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="users" className="mt-0">
                    <Card>
                      <CardHeader className="flex flex-col sm:flex-row sm:items-center gap-4">
                        <div>
                          <CardTitle>Usuários</CardTitle>
                          <CardDescription>
                            Gerencie os usuários do sistema
                          </CardDescription>
                        </div>
                        <div className="sm:ml-auto flex items-center gap-2">
                          <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="search"
                              placeholder="Buscar usuários..."
                              className="pl-8"
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                            />
                          </div>
                          <Button>Novo Usuário</Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 px-2">ID</th>
                                <th className="text-left py-3 px-2">Nome</th>
                                <th className="text-left py-3 px-2">Usuário</th>
                                <th className="text-left py-3 px-2">E-mail</th>
                                <th className="text-left py-3 px-2">Papel</th>
                                <th className="text-left py-3 px-2">Criado em</th>
                                <th className="text-right py-3 px-2">Ações</th>
                              </tr>
                            </thead>
                            <tbody>
                              {filterItems(users, searchTerm).map((user) => (
                                <tr key={user.id} className="border-b">
                                  <td className="py-3 px-2">#{user.id}</td>
                                  <td className="py-3 px-2">{user.name}</td>
                                  <td className="py-3 px-2">{user.username}</td>
                                  <td className="py-3 px-2">{user.email}</td>
                                  <td className="py-3 px-2">
                                    <Badge variant={user.role === "admin" ? "default" : "outline"}>
                                      {user.role === "admin" ? "Admin" : "Cliente"}
                                    </Badge>
                                  </td>
                                  <td className="py-3 px-2">
                                    {format(new Date(user.createdAt), "dd/MM/yyyy", {locale: ptBR})}
                                  </td>
                                  <td className="py-3 px-2 text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button size="icon" variant="ghost">
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button size="icon" variant="ghost">
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="customers" className="mt-0">
                    <Card>
                      <CardHeader className="flex flex-col sm:flex-row sm:items-center gap-4">
                        <div>
                          <CardTitle>Clientes</CardTitle>
                          <CardDescription>
                            Gerenciamento de clientes e suas informações
                          </CardDescription>
                        </div>
                        <div className="sm:ml-auto flex items-center gap-2">
                          <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="search"
                              placeholder="Buscar clientes..."
                              className="pl-8"
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                            />
                          </div>
                          <Button>Novo Cliente</Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 px-2">ID</th>
                                <th className="text-left py-3 px-2">Nome</th>
                                <th className="text-left py-3 px-2">CPF/CNPJ</th>
                                <th className="text-left py-3 px-2">E-mail</th>
                                <th className="text-left py-3 px-2">Telefone</th>
                                <th className="text-left py-3 px-2">Cidade</th>
                                <th className="text-right py-3 px-2">Ações</th>
                              </tr>
                            </thead>
                            <tbody>
                              {filterItems(customers, searchTerm).map((customer) => (
                                <tr key={customer.id} className="border-b">
                                  <td className="py-3 px-2">#{customer.id}</td>
                                  <td className="py-3 px-2">{customer.name}</td>
                                  <td className="py-3 px-2">{customer.documentNumber}</td>
                                  <td className="py-3 px-2">{customer.email}</td>
                                  <td className="py-3 px-2">{customer.phone}</td>
                                  <td className="py-3 px-2">{customer.city}</td>
                                  <td className="py-3 px-2 text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button size="icon" variant="ghost">
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button size="icon" variant="ghost">
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="subscriptions" className="mt-0">
                    <Card>
                      <CardHeader className="flex flex-col sm:flex-row sm:items-center gap-4">
                        <div>
                          <CardTitle>Assinaturas</CardTitle>
                          <CardDescription>
                            Gerenciamento de assinaturas e contratos
                          </CardDescription>
                        </div>
                        <div className="sm:ml-auto flex items-center gap-2">
                          <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="search"
                              placeholder="Buscar assinaturas..."
                              className="pl-8"
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                            />
                          </div>
                          <Button>Nova Assinatura</Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 px-2">ID</th>
                                <th className="text-left py-3 px-2">Cliente</th>
                                <th className="text-left py-3 px-2">Plano</th>
                                <th className="text-left py-3 px-2">Status</th>
                                <th className="text-left py-3 px-2">Início</th>
                                <th className="text-left py-3 px-2">Renovação</th>
                                <th className="text-right py-3 px-2">Ações</th>
                              </tr>
                            </thead>
                            <tbody>
                              {(subscriptions || []).map((subscription) => (
                                <tr key={subscription.id} className="border-b">
                                  <td className="py-3 px-2">#{subscription.id}</td>
                                  <td className="py-3 px-2">#{subscription.customerId}</td>
                                  <td className="py-3 px-2">#{subscription.planId}</td>
                                  <td className="py-3 px-2">
                                    <Badge
                                      variant={
                                        subscription.status === "active"
                                          ? "default"
                                          : subscription.status === "suspended"
                                          ? "secondary"
                                          : "destructive"
                                      }
                                    >
                                      {subscription.status === "active"
                                        ? "Ativo"
                                        : subscription.status === "suspended"
                                        ? "Suspenso"
                                        : "Cancelado"}
                                    </Badge>
                                  </td>
                                  <td className="py-3 px-2">
                                    {format(new Date(subscription.startDate), "dd/MM/yyyy", {locale: ptBR})}
                                  </td>
                                  <td className="py-3 px-2">
                                    {format(new Date(subscription.renewalDate), "dd/MM/yyyy", {locale: ptBR})}
                                  </td>
                                  <td className="py-3 px-2 text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button size="icon" variant="ghost">
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button size="icon" variant="ghost">
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="payments" className="mt-0">
                    <Card>
                      <CardHeader className="flex flex-col sm:flex-row sm:items-center gap-4">
                        <div>
                          <CardTitle>Pagamentos</CardTitle>
                          <CardDescription>
                            Histórico de pagamentos e faturas
                          </CardDescription>
                        </div>
                        <div className="sm:ml-auto flex items-center gap-2">
                          <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="search"
                              placeholder="Buscar pagamentos..."
                              className="pl-8"
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                            />
                          </div>
                          <Button>Registrar Pagamento</Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 px-2">ID</th>
                                <th className="text-left py-3 px-2">Cliente</th>
                                <th className="text-left py-3 px-2">Data</th>
                                <th className="text-left py-3 px-2">Vencimento</th>
                                <th className="text-left py-3 px-2">Valor</th>
                                <th className="text-left py-3 px-2">Método</th>
                                <th className="text-left py-3 px-2">Status</th>
                                <th className="text-right py-3 px-2">Ações</th>
                              </tr>
                            </thead>
                            <tbody>
                              {(payments || []).map((payment) => (
                                <tr key={payment.id} className="border-b">
                                  <td className="py-3 px-2">#{payment.id}</td>
                                  <td className="py-3 px-2">#{payment.customerId}</td>
                                  <td className="py-3 px-2">
                                    {payment.paymentDate 
                                      ? format(new Date(payment.paymentDate), "dd/MM/yyyy", {locale: ptBR})
                                      : "-"}
                                  </td>
                                  <td className="py-3 px-2">
                                    {format(new Date(payment.dueDate), "dd/MM/yyyy", {locale: ptBR})}
                                  </td>
                                  <td className="py-3 px-2">
                                    R$ {(payment.amount / 100).toFixed(2)}
                                  </td>
                                  <td className="py-3 px-2">
                                    {payment.paymentMethod === "credit_card" 
                                      ? "Cartão de Crédito"
                                      : payment.paymentMethod === "boleto"
                                      ? "Boleto"
                                      : "PIX"}
                                  </td>
                                  <td className="py-3 px-2">
                                    <Badge
                                      variant={
                                        payment.status === "paid"
                                          ? "default"
                                          : payment.status === "pending"
                                          ? "secondary"
                                          : "destructive"
                                      }
                                    >
                                      {payment.status === "paid"
                                        ? "Pago"
                                        : payment.status === "pending"
                                        ? "Pendente"
                                        : "Falhou"}
                                    </Badge>
                                  </td>
                                  <td className="py-3 px-2 text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button size="icon" variant="ghost">
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="plans" className="mt-0">
                    <Card>
                      <CardHeader className="flex flex-col sm:flex-row sm:items-center gap-4">
                        <div>
                          <CardTitle>Planos</CardTitle>
                          <CardDescription>
                            Gerenciamento de planos de internet
                          </CardDescription>
                        </div>
                        <div className="sm:ml-auto flex items-center gap-2">
                          <Button>Novo Plano</Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-3 px-2">ID</th>
                                <th className="text-left py-3 px-2">Nome</th>
                                <th className="text-left py-3 px-2">Velocidade</th>
                                <th className="text-left py-3 px-2">Preço</th>
                                <th className="text-left py-3 px-2">Popular</th>
                                <th className="text-right py-3 px-2">Ações</th>
                              </tr>
                            </thead>
                            <tbody>
                              {(plans || []).map((plan) => (
                                <tr key={plan.id} className="border-b">
                                  <td className="py-3 px-2">#{plan.id}</td>
                                  <td className="py-3 px-2">{plan.name}</td>
                                  <td className="py-3 px-2">{plan.speed} Mbps</td>
                                  <td className="py-3 px-2">
                                    R$ {(plan.price / 100).toFixed(2)}
                                  </td>
                                  <td className="py-3 px-2">
                                    {plan.isPopular ? "Sim" : "Não"}
                                  </td>
                                  <td className="py-3 px-2 text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button size="icon" variant="ghost">
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button size="icon" variant="ghost">
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="settings" className="mt-0">
                    <Card>
                      <CardHeader>
                        <CardTitle>Configurações do Sistema</CardTitle>
                        <CardDescription>
                          Gerenciar configurações gerais do sistema
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-6">
                          <div className="space-y-2">
                            <h3 className="text-lg font-semibold">Configurações Gerais</h3>
                            <div className="space-y-4">
                              <div className="grid gap-2">
                                <Label htmlFor="company-name">Nome da Empresa</Label>
                                <Input id="company-name" defaultValue="ALTO.NET" />
                              </div>
                              <div className="grid gap-2">
                                <Label htmlFor="contact-email">E-mail de Contato</Label>
                                <Input id="contact-email" defaultValue="contato@altonet.com.br" />
                              </div>
                              <div className="grid gap-2">
                                <Label htmlFor="contact-phone">Telefone de Contato</Label>
                                <Input id="contact-phone" defaultValue="(74) 99999-9999" />
                              </div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <h3 className="text-lg font-semibold">Gateway de Pagamento</h3>
                            <div className="space-y-4">
                              <div className="grid gap-2">
                                <Label htmlFor="mercadopago-token">Token Mercado Pago</Label>
                                <Input id="mercadopago-token" type="password" defaultValue="••••••••••••••••" />
                              </div>
                              <div className="grid gap-2">
                                <Label htmlFor="mercadopago-mode">Ambiente</Label>
                                <select 
                                  id="mercadopago-mode" 
                                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outlinenone focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                  defaultValue="sandbox"
                                >
                                  <option value="sandbox">Sandbox (Testes)</option>
                                  <option value="production">Produção</option>
                                </select>
                              </div>
                            </div>
                          </div>

                          <div className="flex justify-end">
                            <Button>Salvar Configurações</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}