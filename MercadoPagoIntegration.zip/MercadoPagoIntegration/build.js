// Este script prepara os arquivos para deploy no Netlify
// Execute com: node build.js

import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';

// Função para executar comandos shell com promise
function runCommand(command) {
  return new Promise((resolve, reject) => {
    console.log(`Executando: ${command}`);
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Erro: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        console.log(`stderr: ${stderr}`);
      }
      console.log(`stdout: ${stdout}`);
      resolve(stdout);
    });
  });
}

async function build() {
  try {
    // 1. Build frontend com Vite
    console.log('🚀 Iniciando build do frontend...');
    await runCommand('npm run build');
    
    // 2. Build das funções serverless para Netlify
    console.log('🚀 Iniciando build das funções serverless...');
    await runCommand('esbuild server/netlify-functions.ts --platform=node --packages=external --bundle --format=esm --outdir=server');
    
    // 3. Copiar arquivo _redirects para a pasta dist
    console.log('📋 Copiando arquivo _redirects...');
    fs.copyFileSync('_redirects', 'dist/_redirects');
    
    console.log('✅ Build concluído com sucesso!');
    console.log('Para fazer deploy, utilize o Netlify CLI ou faça upload da pasta dist para o Netlify.');
    
  } catch (error) {
    console.error('❌ Erro durante o build:', error);
    process.exit(1);
  }
}

build();